
      SUBROUTINE RATES

       INCLUDE '../INCLUDECHEM/parNZ.inc'
       INCLUDE '../INCLUDECHEM/parNQ_NQT.inc'
       INCLUDE '../INCLUDECHEM/parNR.inc'
       INCLUDE '../INCLUDECHEM/parNSP_NSP1_NSP2.inc'
       INCLUDE '../INCLUDECHEM/parNMAX.inc'

      DIMENSION A3(NZ),A4(NZ),A5(NZ),A6(NZ),A10(NZ),A11(NZ),A12(NZ),
     2  A13(NZ),A14(NZ),A15(NZ),A16(NZ),A17(NZ),A18(NZ),A19(NZ),
     3  A20(NZ),A21(NZ),A22(NZ),A30(NZ),A31(NZ),A32(NZ),A41(NZ),
     4  A43(NZ),A46(NZ),A47(NZ),A48(NZ),W1(NZ),W2(NZ),W3(NZ),W4(NZ),
     5  W5(NZ),W6(NZ),W7(NZ),W8(NZ),W9(NZ),W10(NZ),W11(NZ),W12(NZ),
     6  PD(NZ)
      
      INCLUDE '../INCLUDECHEM/comABLOK.inc'
      INCLUDE '../INCLUDECHEM/comCBLOK.inc'     
      INCLUDE '../INCLUDECHEM/comGBLOK.inc'
      INCLUDE '../INCLUDECHEM/comRBLOK.inc'
      INCLUDE 'INCLUDECHEM/comPRESS1.inc'

C
C ***** TEMPERATURE-DEPENDENT RATE COEFFICIENTS *****
C
c      print *, 'CHEMICAL LOSS MATRIX'
c      DO J = 1,NSP
c      print 601,J, (ILOSS(1,J,K),K = 1,30)
c      end do
c      DO J = 1,NSP
c      print 601,J, (ILOSS(2,J,K),K = 1,30)
c      end do
c
c      PRINT *,'PRODUCTION MATRIX'
c      Do J = 1, NSP
c      Print 601,J,(IPROD(J,K),K = 1,30)
c      end do
c  601 format(31I4)

      DO 1 I=1,NZ
      PATM = DEN(I)*1.38E-16*T(I)/1.013E6
      A3(I) = 3.44E-13*((T(I)/298.)**2.67)*EXP(-3160./T(I))
      A4(I) = 7.7E-12*EXP(-2100./T(I))
      A5(I) = 1.4E-10*EXP(-470./T(I))
      A10(I) = 1.8E-11*EXP(180./T(I))
      A12(I) = 1.7E-12*EXP(-940./T(I))
      A13(I) = 3.0E-11*EXP(200./T(I))
      A14(I) = 1.0E-14*EXP(-490./T(I))
      A15(I) = 3.0E-13*EXP(460./T(I))
      A16(I) = 2.9E-12*EXP(-160./T(I))
      A17(I) = 5.21E-35*EXP(900./T(I))*DEN(I)
      A19(I) = 8.0E-12 * EXP(-2060./T(I))
      A20(I) = 1.8E-12
      A21(I) = 0.!2.15E-11*EXP(110./T(I))JL:duplicated with rxn 383
      A22(I) = 0.!3.3E-11*EXP(55./T(I))JL:replace with rxn 430 and 431. 
C      A30(I) = 1.5E-13 * (1. + 0.6*PATM)
      A31(I) = 1.7E-33*EXP(-1510./T(I))*DEN(I)
      A32(I) = 5.29E-34*EXP(-370./T(I))*DEN(I)
      A41(I) = 2.14E-12*((T(I)/298.)**1.62)*EXP(-1090./T(I))
      A43(I) = 6.04E-33*(T(I)/298.)*DEN(I)
      A46(I) = 4.38E-30*((T(I)/298.)**-2.00)*DEN(I)
      A48(I) = 3.4E-11*EXP(-1600./T(I))
   1  CONTINUE
C
C ***** THREE-BODY COEFFICIENTS *****
      DO 3 I=1,NZ
      TT = T(I)
      DN = DEN(I)
C     AR(J,I) = TBDY(K0,KI,N,M,T,DEN)
C
C  HO2
      AR(6,I) = TBDY(5.3E-32,9.5E-11,-1.8,0.4,TT,DN)
C
C  O3
      AR(18,I) = TBDY(6.1E-34,1.5E-14,-2.4,0.,TT,DN)
C
C  CO2
      AR(30,I) = TBDY(6.99E-33,1.1E-12,2.1,-1.3,TT,DN)
C
C  H2O2
      AR(47,I) = TBDY(6.9E-31,2.6E-11,-1.0,0.,TT,DN)
C
C   CH3O2
      AR(67,I) = TBDY(4.1E-31,1.2E-12,-3.6,1.1,TT,DN)
C
C   NO2
      AR(84,I) = TBDY(9.1E-32,3.E-11,-1.5,0.,TT,DN)
C
C   HNO2
      AR(86,I) = TBDY(7.1E-31,3.6E-11,-2.6,-0.1,TT,DN)
C
C   HNO3
      AR(88,I) = TBDY(1.8E-30,2.8E-11,-3.0,0.,TT,DN)
C
C   NO3 
      AR(90,I) = TBDY(3.9E-31,1.5E-13,7.2,4.8,TT,DN)
C
C   HO2NO2
      AR(91,I) = TBDY(1.9E-31,4.0E-12,-3.4,-0.3,TT,DN)
C
C   NOCL
      AR(114,I) = TBDY(7.7E-32,1.9E-12,-1.8,0.,TT,DN)
C
C   CLONO
      AR(115,I) = TBDY(1.8E-31,1.E-10,-2.,-1.,TT,DN)
C
C   CLO2
      AR(117,I) = TBDY(2.2E-33,1.8E-10,-3.1,0.,TT,DN)
c
C   CLONO2
      AR(122,I) = TBDY(1.8E-31,1.5E-11,-3.4,-1.9,TT,DN)
C
C   CL2O2
      AR(141,I) = TBDY(1.9E-32,3.7E-12,-3.6,-1.6,TT,DN)
C
C   NO3
      AR(150,I) = TBDY(3.4E-31,2.3E-11,1.50,0.2,TT,DN)
C
C   N2O5
      AR(152,I) = TBDY(2.4E-30,1.6E-12,-3.0,0.1,TT,DN)
c
c-JL June 2022 move N2O5 decomposition(NO2+NO3) here to avoid glitch
      AR(154,I) = TBDY(1.3E-19,5.7E-14,0.,0.,TT,DN)
C
C   HSO3
      AR(163,I) = TBDY(2.9E-31,1.7E-12,-4.1,0.2,TT,DN)
C
C   SO3
      AR(164,I) = TBDY(1.8E-33,4.1E-14,2.0,1.8,TT,DN)
C   
c   N2O
      AR(218,I) = TBDY(2.8E-36,6.9E-17,-0.9,0.,TT,DN)
c
c   INO2
      AR(256,I) = TBDY(3.0E-31,6.6E-11,-1.0,0.,TT,DN) !I + NO2 + M
c
c   INO3
      AR(257,I) = TBDY(7.7E-31,7.7E-12,-3.5,-1.5,TT,DN)!IO + NO2 + M
c
c   INO 
      AR(258,I) = TBDY(1.8E-32,1.7E-11,-1.0,0.,TT,DN) !I + NO + M
C   BRNO3
      AR(440,I) = TBDY(5.5E-31,6.6E-12,-3.1,-2.9,TT,DN)!BRO + NO2 + M
C   BRNO2
      AR(443,I) = TBDY(4.3E-31,2.7E-11,-2.4,0.,TT,DN)!BR + NO2 + M
   3  CONTINUE
C
C ***** FILL UP RATE MATRIX *****
      DO 4 I=1,NZ
      AR(1,I) = 1.63E-10*EXP(60./T(I))
      AR(2,I) = 1.20E-10
      AR(3,I) = A3(I)
      AR(4,I) = A4(I)
      AR(5,I) = A5(I)
      AR(7,I) = 6.9E-12
      AR(8,I) = 1.6E-12
      AR(9,I) = 7.2E-11
      AR(10,I) = A10(I)
      AR(11,I) = 4.8E-11*EXP(250./T(I))
      AR(12,I) = A12(I)
      AR(13,I) = A13(I)
      AR(14,I) = A14(I)
      AR(15,I) = A15(I)
      AR(16,I) = A16(I)
      AR(17,I) = A17(I)
      AR(19,I) = A19(I)
      AR(20,I) = A20(I)
      AR(21,I) = A21(I)
      AR(22,I) = A22(I)
c      AR(30,I) = A30(I)
      AR(31,I) = A31(I)
      AR(32,I) = A32(I)
      AR(33,I) = 1.50E-10
      AR(34,I) = 0.
      AR(35,I) = 1.69E-10
      AR(36,I) = 5.00E-11
      AR(37,I) = 5.00E-11
      AR(40,I) = 1.0E-2
      AR(41,I) = A41(I)
      AR(43,I) = A43(I)
      AR(44,I) = 3.5E-12 * EXP(140./T(I))
      AR(45,I) = 8.20E-12*EXP(40./T(I))
      AR(46,I) = A46(I)
      AR(48,I) = A48(I)
      AR(49,I) = 1.4E-12 * EXP(-2000./T(I))
      AR(58,I) = 4.16E-13*((T(I)/298.)**2.18)*EXP(-1230./T(I))
      AR(59,I) = 0.75*1.75E-10
      AR(60,I) = 0.05*1.75E-10
      AR(61,I) = 5.9E-11
      AR(62,I) = 6.64E-14
      AR(63,I) = 8.8E-12
      AR(64,I) = 5.E-15
      AR(65,I) = 7.1E-12*EXP(-5051./T(I))
      AR(66,I) = 6.64E-14
      AR(68,I) = 2.59E-13*((T(I)/298.)**-0.53)*EXP(-5440./T(I))
      AR(69,I) = 1.1E-10
      AR(70,I) = 5.4E-12 * EXP(-220./T(I))
      AR(71,I) = 3.8E-13 * EXP(780./T(I))
      AR(72,I) = 7.40E-13 * EXP(-520./T(I))
      AR(73,I) = 2.8E-12 * EXP(285./T(I))
      AR(74,I) = 3.9E-14*EXP(-900./T(I))
      AR(75,I) = 1.E-14
   4  CONTINUE
c
      DO 5 I=1,NZ
      AR(76,I) = 3.2E-13
      AR(77,I) = 0.61*1.19E-10*EXP(20./T(I))
      AR(78,I) = 0.39*1.19E-10*EXP(20./T(I))
      AR(79,I) = 3.3E-12*EXP(-3150./T(I))
      AR(80,I) = 1.0E-16
      AR(81,I) = 4.70E-11
      AR(82,I) = 2.1E-11*EXP(100./T(I))
      AR(83,I) = 3.0E-12*EXP(-1500./T(I))
      AR(85,I) = 3.44E-12*EXP(260./T(I))
      AR(87,I) = 5.50E-12*EXP(200./T(I))
      AR(89,I) = 1.47E-10
C      AK0 = 7.2E-15*EXP(785./T(I))
C      AK2 = 4.1E-16*EXP(1440./T(I))
C      AK3M = 1.9E-33*EXP(725./T(I))*DEN(I)
C      AR(90,I) = AK0 + AK3M/(1. + AK3M/AK2)
      AR(92,I) = 1.90E-12 * EXP(270./T(I))
      AR(93,I) = 7.8E-11 * EXP(-3400./T(I))
      AR(94,I) = AR(91,I)/(2.33E-27*EXP(10870./T(I)))
      AR(96,I) = 1.9E-12 * EXP(190./T(I))
      AR(97,I) = AR(11,I)
      AR(98,I) = 1.20E-13*EXP(-2450./T(I))
      AR(99,I) = 4.35E-14*EXP(-1335./T(I))
      AR(100,I) = 1.3E-11
      AR(102,I) = 1.70E-11*EXP(125./T(I))
      AR(103,I) = 2.E-11
      AR(104,I) = 1.96E-12*EXP(-1200./T(I))
      AR(105,I) = 2.30E-11*EXP(-200./T(I))
      AR(106,I) = 3.05E-11*EXP(-2270./T(I))
      AR(107,I) = 7.1E-12*EXP(-1270./T(I))
      AR(108,I) = 2.03E-11*EXP(-1110./T(I))
      AR(109,I) = 8.1E-11*EXP(-30./T(I))
      AR(110,I) = 1.1E-11*EXP(-980./T(I))
      AR(111,I) = 1.4E-11*EXP(270./T(I))
      AR(112,I) = 3.6E-11*EXP(-375./T(I))
      AR(113,I) = 6.5E-12*EXP(135./T(I))
      AR(116,I) = 5.8E-11*EXP(100./T(I))
      AR(118,I) = 2.3E-10
      AR(119,I) = 1.2E-11
      AR(120,I) = 2.8E-11*EXP(85./T(I))
      AR(121,I) = 6.4E-12*EXP(290./T(I))
      AR(123,I) = 2.6E-12*EXP(290./T(I))
      AR(124,I) = 0.!1.1E-11*EXP(120./T(I))
      AR(125,I) = 1.8E-12*EXP(-250./T(I))
      AR(126,I) = 3.0E-12*EXP(-500./T(I))
      AR(127,I) = 1.2E-12*EXP(-330./T(I))
      AR(128,I) = 1.0E-11*EXP(-3300./T(I))
      AR(129,I) = 1.70E-13
      AR(130,I) = 3.6E-12*EXP(-840./T(I))
      AR(131,I) = 2.6E-12*EXP(-1100./T(I))
      AR(139,I) = AR(117,I)/(2.43E-25*EXP(2979./T(I)))
      AR(140,I) = 1.91E-12
   5  CONTINUE
C
      DO 6 I=1,NZ
      AR(143,I) = AR(141,I)/(3.E-27*EXP(8450./T(I)))
      AR(144,I) = AR(117,I)/(5.7E-25*EXP(2500./T(I)))
      AR(145,I) = 2.40E-11
      AR(146,I) = 3.4E-12*EXP(-130./T(I))
      AR(147,I) = 0.!4.E-13
      AR(148,I) = 0.!2.4E-12
      AR(149,I) = 2.4E-12*EXP(-960./T(I))
      AR(155,I) = 2.5E-22
C  AR(155,I) should be viewed as a tuning parameter. The gas phase upper 
C  limit is 2.e-21. A value 100 times higher than this yields an effective
C  first-order rate of ~2.e-5 in the lower stratosphere.
 6    CONTINUE
C-AP
C-AP Adding sulfur rate constants
C
C-AP
      DO 7 I=1,NZ
      AR(159,I) = 1.60E-13 * EXP(-2280./T(I))
      AR(160,I) = 2.8E-11
      AR(161,I) = 6.0E-31 * DEN(I)
      AR(162,I) = 8.6E-11
c      AR(164,I) = 3.4E-32 * EXP(-1130./T(I)) * DEN(I)
      AR(165,I) = 6.0E-15
      AR(166,I) = 1.3E-12 *EXP(-330./T(I))
      AR(167,I) = 1.0E-11
      AR(168,I) = 1.0E-11
      AR(169,I) = 1.0E-11
      AR(170,I) = 6.10E-12 * EXP(-80./T(I))
      AR(171,I) = 3.66E-12*((T(I)/298.)**1.94)*EXP(-455./T(I))
      AR(172,I) = 9.22E-12 * EXP(-1800./T(I))
      AR(173,I) = 1.6E-10
      AR(174,I) = 4.0E-19
      AR(175,I) = 3.0E-11
      AR(176,I) = 1.2E-11
      AR(177,I) = 5.0E-11
      AR(178,I) = 1.0E-11
      AR(179,I) = 2.2E-11 * EXP(120./T(I))
      AR(180,I) = 2.10E-12
      AR(181,I) = 6.6E-11
C-AP We need to zero out this reaction S +HCO ->HS +CO because both S and HCO are short-lived
C-AP      AR(182,I) = 5.0E-11
C-KK	This reaction has been removed from the primo3s rxn list.
C-KK      AR(182,I) = 1.E-99
      AR(183,I) = 1.5E-11
      AR(184,I) = 1.5E-11
      AR(185,I) = 1.7E-11 * EXP(-800./T(I))
   7  CONTINUE
C-AP 
C
      DO 8 I=1,NZ
      AR(190,I) = 1.0E-12
      AR(191,I) = 1.0E-11
      AR(192,I) = 1.5E+3
      AR(193,I) = 2.2E+4
      AR(194,I) = 1.0E-16
      AR(195,I) = 4.0E-12
      AR(196,I) = 1.5E-13
      AR(197,I) = 1.13E+3
      AR(198,I) = 7.0E-14
      AR(199,I) = 1.4E-11
      AR(200,I) = 4.50E-12 * EXP(-1170./T(I))
c place holder for 201
      AR(201,I) = 1.0E-15
      AR(202,I) = 9.50E-12 * EXP(-280./T(I))
      AR(203,I) = 2.9E-11 * EXP(240./T(I))
      AR(204,I) = 1.2E-11
      AR(205,I) = 8.3E-15
      AR(206,I) = 2.0E-15
      AR(207,I) = 1.0E-20
c place holder for 208
      AR(208,I) = 1.0E-15
      AR(209,I) = AR(44,I)
      AR(210,I) = AR(6,I)
      AR(212,I) = AR(11,I)
      AR(213,I) = AR(9,I)
      AR(214,I) = AR(7,I)
      AR(215,I) = 1.E-12
      AR(216,I) = AR(13,I)
      AR(217,I) = 1.E-11
      AR(219,I) = 5.03E-7*((298./T(I))**2.16)*EXP(-18701./T(I))
      AR(220,I) = 2.E-14 * EXP(-25000./T(I))
   8  continue 
c-set up pressure dependent prameters for I2O2,I2O3,I2O4,INO3
      DO 9 I = 1,NZ 
      PD(I) = PRESS(I)/1000.!convert dyne to hpa 
   9  continue 
c-from Saiz-Lopez et al.2014 ACP
      DO 10 I = 1,NZ
      W1(I) = 4.687E-10 -1.3855E-5*EXP(-0.75*PD(I)/1.62265)+ 
     2  5.51868E-10*EXP(-0.75*PD(I)/199.328)
      W2(I) = -3.31E-3 - 5.14E-3*EXP(-0.75*PD(I)/325.68711) -
     2  4.44E-3*(EXP(-0.75*PD(I)/40.81609))
C
      W3(I) = 1.1659E-9 - 7.79644E-10*EXP(-0.75*PD(I)/22.09281) +
     2  1.03779E-9*EXP(-0.75*PD(I)/568.15381)
      W4(I) = -8.13E-3 - 3.82E-3*EXP(-0.75*PD(I)/45.57591) -
     2   6.43E-3*EXP(-0.75*PD(I)/417.95061) 
C
      W5(I) = 3.54288E10 + 1.8523E11*0.75*PD(I) - 1.45435E8*(0.75*PD(I))
     2  **2. + 60799.4344*(0.75*PD(I))**3.
      W6(I) = -9681.65989 + 346.95538*EXP(-0.75*PD(I)/343.25322) +
     2  251.78032*EXP(-0.75*PD(I)/44.1466)
C
      W7(I) = 2.55335E11 - 4.41888E9*0.75*PD(I) + 85618600*
     2  (0.75*PD(I))**2. + 14218.81*(0.75*PD(I))**3.
      W8(I) = -11466.82304 + 597.01334*EXP(-0.75*PD(I)/343.25322) -
     2  167.3391*(EXP(-0.75*PD(I)/43.75089))
c
      W9(I) = -1.92626E14 + 4.67414E13*0.75*PD(I)-3.68651E8*(0.75*PD(I))
     2  **2.-  3.09109E6*(0.75*PD(I))**3. 
      W10(I) = -12302.15294 + 252.78367*EXP(-0.75*PD(I)/46.12733) +
     2  437.62868*EXP(-0.75*PD(I)/428.4413) 
c 
      W11(I) = -2.63544E13 + 4.32845E12*0.75*PD(I) + 3.73758E8*((0.75*
     2  PD(I))**2.) - 628468.76313*((0.75*PD(I))**3.)
      W12(I) = -13847.85015 + 240.34465*EXP(-0.75*PD(I)/49.27141) +
     2  451.35864*EXP(-0.75*PD(I)/436.87605)
c
   10  continue 
c
c
c-JL ADD IODINE CHEMISTRY
      DO 11 I = 1,NZ  
      AR(221,I) = 2.0E-11*EXP(-830./T(I))   !  I + O3  =   IO +  O2
      AR(222,I) = 3.6E-16*0.5               ! IO + O3  =  IO2 +  O2
      AR(223,I) = 0.!1.5E-11*EXP(-1090./T(I))  !  I + HO2 =   IH +  O2
      AR(224,I) = 8.6E-12*EXP(230./T(I))    ! IO + NO  =    I + NO2
      AR(225,I) = 1.3E-11*EXP(570./T(I))    ! IO + HO2 =  IHO + O2
      AR(226,I) = 5.4E-11*EXP(180./T(I))*0.45!2.13E-11*EXP(180./T(I))*(1+EXP(-PD(I)/191.42))
      AR(227,I) = 5.4E-11*EXP(180./T(I))*0.55!3.27E-11*EXP(180./T(I))*(1-0.65*EXP(-PD(I)/191.42))
      AR(228,I) = 1.3E-10
      AR(229,I) = 1.5E-10 !6.7E-11 !W3(I)*EXP(W4(I)*T(I))
      AR(230,I) = 1.3E-10                   ! I2 + O   =   IO + I
      AR(231,I) = 1.4E-10                   ! IO + O   =    I + O2
      AR(232,I) = 1.0E-10                   ! IO + OH  =  HO2 + I
c-JL decomposition
      AR(233,I) = 0.5*2.5E14*EXP(-9770./T(I)) !0.5*1.13 !0.5*1.2E-3 !0.21 ! !W5(I)*EXP(W6(I)/T(I))/DEN(I)
      AR(234,I) = 0.5*1.0E12*EXP(-9770./T(I))!0.5*4.0E-2 !W7(I)*EXP(W8(I)/T(I))/DEN(I)
      AR(235,I) = 8.79E-2 !W9(I)*EXP(W10(I)/T(I))!/DEN(I)
c
      AR(236,I) = 1.8E-10                   ! I2 + OH = IHO + I  
      AR(237,I) = 1.5E-12                   ! I2 + NO3 = I + INO3
      AR(238,I) = 1.0E-10                   ! I + NO3 = IO + NO2 
      AR(239,I) = 1.6E-11*EXP(440./T(I)) !3.0E-11  ! OH + IH = I + H2O 
      AR(240,I) = 1.5E-11*EXP(-1090./T(I))  ! HO2 + I = IH + O2 
      AR(241,I) = 9.1E-11*EXP(-146./T(I))   ! I + INO3 = I2 + NO3
      AR(242,I) = 3.6E-27*EXP(2395./T(I))*(T(I)**4.41) !2.0E-13       ! IHO + OH = IO + H2O
c-JL decomposition
      AR(243,I) = 9.94E17*EXP(-11859./T(I))!/DEN(I)!because INO2+M ! INO2  = I + NO2     
      AR(244,I) = 1.1E15*EXP(-12060./T(I))!/DEN(I) !W11(I)*EXP(W12(I)/T(I))/DEN(I)!because INO3+M
c
      AR(245,I) = 8.4E-11*EXP(-2620./T(I))  ! INO + INO = I2 + 2NO
      AR(246,I) = 2.9E-11*EXP(-2600./T(I))  ! INO2 + INO2 = I2 + 2NO2
      AR(247,I) = 1.1E-12*EXP(542./T(I))    ! IO2 + NO = IO + NO2
      AR(248,I) = 1.3E-12*EXP(-1830./T(I))  ! IH + NO3 = I + HNO3
      AR(249,I) = 2.7E-12*EXP(280./T(I))    ! IO + CLO = I + CLO2
      AR(250,I) = 1.2E-12*EXP(280./T(I))    ! IO + CLO = I + CL + O2
      AR(251,I) = 9.2E-13*EXP(280./T(I))    ! IO + CLO = ICL + O2
      AR(252,I) = 9.0E-12                   ! IO + NO3 = IO2 + NO2
      AR(253,I) = 2.0E-12                   ! IO + CH3O2 = CH2O + I + HO2
      AR(254,I) = 2.9E-12*EXP(-1100./T(I))  ! CH3I + OH = H2O + CH2I
      AR(255,I) = 2.9E-11*EXP(-1000./T(I))  ! CH3I + CL = CH2I + HCL
      AR(259,I) = 2.69E-28*((T(I)/298.)**-6.92)*EXP(-3778./T(I))!CLO + CL 
   11 continue 
c      
      DO 12 I = 1,NZ    
c      AR(260,I) = 5.8E-6
c      AR(261,I) = 7.29E-3
c      AR(262,I) = 1.0E-10 ! Place holder 
c      AR(263,I) = 6.24E-2 !0.15
c      AR(264,I) = 4.5E-2
c      AR(265,I) = 2.55E-1
c      AR(266,I) = 8.2E-6
c      AR(267,I) = 2.07E-2
c      AR(268,I) = 5.53E-4*0.5
c      AR(269,I) = 7.21E-5
c      AR(270,I) = 1.26E-3 !3.29E-4
c      AR(271,I) = 5.46E-3
      AR(272,I) = 1.92E-2
      AR(273,I) = 1.92E-2
      AR(274,I) = 1.92E-2
   12 CONTINUE 
c-JL COMPLETE CLORINE CHEMISTRY
      DO 13, I = 1,NZ       
      AR(275,I) = 5.7E-11                    ! CL + CH3OOH = HCL + CH3O2
      AR(276,I) = 2.7E-11*EXP(-530./T(I))    ! CL2O + O = CLO + CLO
      AR(277,I) = 7.4E-12*EXP(270./T(I))     ! CLO + OH = CL + HO2
      AR(278,I) = 6.0E-13*EXP(230./T(I))     ! CLO + OH = HCL + O2
      AR(279,I) = 1.4E-12*EXP(600./T(I))     ! CLO2 + OH = HOCL + O2
      AR(280,I) = 4.7E-12*EXP(140./T(I))     ! CL2O + OH = HOCL + CLO 
      AR(281,I) = 6.0E-13*EXP(670./T(I))     ! CL2O2 + OH = HOCL + CLO2
      AR(282,I) = 2.4E-12*EXP(-1250./T(I))   ! CLONO + OH = HOCL + NO2
      AR(283,I) = 2.5E-12*EXP(-600./T(I))    ! CLO2 + NO = NO2 + CLO
      AR(284,I) = 1.0E-17                    ! HCL + NO3 = HNO3 + CL 
      AR(285,I) = 6.2E-11*EXP(130./T(I))     ! CL2O + CL = CL2 + CLO
      AR(286,I) = 2.0E-12*EXP(-4000./T(I))   ! CLO + O3 = CLO2 + O2 
      AR(287,I) = 4.7E-13                    ! CLO + NO3 = CLO2 + NO2
      AR(288,I) = 1.0E-12*EXP(-1590./T(I))   ! CLO + CLO = CL2 + O2 
      AR(289,I) = 3.0E-11*EXP(-2450./T(I))   ! CLO + CLO = CLO2 + CL
      AR(290,I) = 0. !1.6E-10 mass imbalance  ! CL + CH3O2 = CLO + CH2O + HO2
   13 CONTINUE  
C
c-JL ADDITIONAL IODINE CHEMISTRY
      DO 14 I = 1, NZ  
c      AR(291,I) = 5.53E-4*0.5
c      AR(292,I) = 1.77E-4
      AR(293,I) = 0.5*2.7E-12*((300./T(I))**2.66)!0.5 for day-night
      AR(294,I) = 7.0E-12
      AR(295,I) = 3.82E-11*EXP(-16365./T(I))
      AR(296,I) = 6.3E-11*EXP(-602./T(I))
      AR(297,I) = 4.1E-12*EXP(-1239./T(I))
      AR(298,I) = 9.1E-11*EXP(-1564./T(I))
      AR(299,I) = 1.0E-11*EXP(160./T(I))*0.59
      AR(300,I) = 1.0E-11*EXP(160./T(I))*0.21
      AR(301,I) = 1.0E-11*EXP(160./T(I))*0.09
      AR(302,I) = 1.0E-11*EXP(160./T(I))*0.07
      AR(303,I) = 3.6E-13! CH2I + O2 = H2CO + IO, implies low pCH2I
      AR(304,I) = 1.E16*EXP(-22612./T(I)) ! 2.51E15*EXP(-21299./T(I))!/DEN(I) ! because CH2I2 + M
      AR(305,I) = 1.69E-12*EXP(120./T(I))
      AR(306,I) = 4.17E-10*EXP(-1030./T(I))
      AR(307,I) = 1.33E-10
      AR(308,I) = 4.68E-10*EXP(-7604./T(I))
      AR(309,I) = 3.32E-10
      AR(310,I) = 1.47E-15*(T(I)/298.)**2.59*EXP(-4610./T(I)) !NIST 6.69E-20*EXP(-26835./T(I))*T(I)**2.09
      AR(311,I) = 4.5E-12*EXP(144./T(I))
      AR(312,I) = 9.96E-12
      AR(313,I) = 1.05E-12*EXP(-6091./T(I)) !NIST 1.05E-12*EXP(-6./T(I))
      AR(314,I) = 6.08E-11*EXP(-361./T(I))
      AR(315,I) = 4.25E-11*EXP(-22021./T(I))
      AR(316,I) = 1.49E-18*EXP(-12394./T(I))*(T(I)**2.28)
      AR(317,I) = 9.7E-16*EXP(-17930./T(I))*(T(I)**1.72)
      AR(318,I) = 3.01E-19*EXP(-673./T(I))*(T(I)**1.72)
      AR(319,I) = 3.6E-14*EXP(-3249./T(I))
      AR(320,I) = 6.68E-11*EXP(-999./T(I))
      AR(321,I) = 3.3E-12*EXP(-11131./T(I))
      AR(322,I) = 1.89E-15*EXP(1155./T(I))*(T(I)**1.49)
      AR(323,I) = 9.96E-16*EXP(-1576./T(I))*(T(I)**1.55)
      AR(324,I) = 1.4E-23*EXP(-2166./T(I))*(T(I)**3.66)
      AR(325,I) = 8.3E-16
   14 CONTINUE 
      DO 15 I = 1, NZ 
      AR(326,I) = 3.8E-18*EXP(-13237./T(I))*(T(I)**2.29)
      AR(327,I) = 2.61E-16*EXP(-5283./T(I))*(T(I)**1.72)
      AR(328,I) = 8.96E-16*((T(I)/298.)**4.65)*EXP(-300./T(I))
      AR(329,I) = 1.3E-31*((T(I)/298.)**1.87)
      AR(330,I) = 4.52E-10*EXP(-17087./T(I))
      AR(331,I) = 5.2E-17*EXP(-21780./T(I))*(T(I)**2.26)
      AR(332,I) = 4.2E-18*EXP(-36462./T(I))*(T(I)**2.48)
      AR(333,I) = 3.11E-20*EXP(-7244./T(I))*(T(I)**2.95)
      AR(334,I) = 4.7E-20*EXP(-14922./T(I))*(T(I)**1.7)
      AR(335,I) = 2.51E-10*EXP(-32250./T(I))
      AR(336,I) = 5.51E-34*EXP(575./T(I))
      AR(337,I) = 1.66E-10
      AR(338,I) = 8.32E-11
      AR(339,I) = 6.59E-10*EXP(-20./T(I))
      AR(340,I) = 1.73E-10*EXP(-20457./T(I))
      AR(341,I) = 1.25E-10
      AR(342,I) = 7.74E-14*EXP(-2888./T(I))*0.5
      AR(343,I) = 7.74E-14*EXP(-2888./T(I))*0.5
      AR(344,I) = 1.37E-10*EXP(-15155./T(I))
      AR(345,I) = 5.0E-16
      AR(346,I) = 1.0E-12
      AR(347,I) = 5.81E-15 !INO--> I + NO
      AR(348,I) = 1.1E-24*EXP(-5270./T(I))*(T(I)**4.0)
      AR(349,I) = 3.2E-27*EXP(-7870./T(I))*(T(I)**4.54)
      AR(350,I) = 5.4E-11*EXP(180./T(I))*0.05
      AR(351,I) = 5.4E-11*EXP(180./T(I))*0.09
      AR(352,I) = 1.2E-15*0.5
      AR(353,I) = 1.49E-17*EXP(-5703./T(I))*(T(I)**1.77)
c-JL complete loss and production for CL2O(also see rxn 259)
      AR(354,I) = 3.4E-12 
      AR(355,I) = 5.49E-13*((T(I)/298.)**1.77)*EXP(-9387./T(I))
      AR(356,I) = 1.49E-15*((T(I)/298.)**3.06)*EXP(-11273./T(I)) 
c-JL complete loss and production for CH2CL,ICL,CH2I2,CH2ICL
      AR(357,I) = 6.12E-18*((T(I)/298.)**6.58)*EXP(6./T(I))
      AR(358,I) = 5.13E-13*((T(I)/298.)**1.91)*EXP(-34./T(I))
      AR(359,I) = 1.95E-14*((T(I)/298.)**3.01)*EXP(-965./T(I))
      AR(360,I) = 1.69E-12*EXP(192./T(I))
      AR(361,I) = 1.33E-10
      AR(362,I) = 3.32E-10
      AR(363,I) = 3.2E-13
      AR(364,I) = 8.5E-17
      AR(365,I) = 2.81E-10
      AR(366,I) = 1.2E-11
      AR(367,I) = 1.3E-12*EXP(-132./T(I))
      AR(368,I) = 2.39E-13*((T(I)/298.)**1.57)*EXP(-2100./T(I))
      AR(369,I) = 6.0E-11
      AR(370,I) = 1.67E-13*((T(I)/298.)**2.52)*EXP(664./T(I))
      AR(371,I) = 5.0E-12
      AR(372,I) = 2.16E-11*EXP(-3470./T(I))
      AR(373,I) = 2.09E-12*EXP(-5841./T(I))
c-JL complete nitrogen and O1D chemistry 
      AR(374,I) = 0.75*2.7E-10
      AR(375,I) = 1.5E-17
      AR(376,I) = 5.8E-12*EXP(220./T(I))
      AR(377,I) = 2.5E-19
      AR(378,I) = 0.1*2.6E-10
      AR(379,I) = 0.46*2.6E-10
      AR(380,I) = 0.09*2.6E-10
      AR(381,I) = 0.5*2.4E-10
      AR(382,I) = 0.5*2.4E-10
      AR(383,I) = 2.15E-11*EXP(110./T(I))
      AR(384,I) = 7.5E-11*EXP(115./T(I))
      AR(385,I) = 0.12*1.5E-10
      AR(386,I) = 0.22*1.5E-10
      AR(387,I) = 0.66*1.5E-10
      AR(388,I) = 0.25*2.7E-10 
      AR(389,I) = 7.56E-17*((T(I)/298.)**3.25)*EXP(-12870./T(I))
      AR(390,I) = 1.77E-15*((T(I)/298.)**3.08)*EXP(-25259./T(I))         
   15 CONTINUE
      DO 16 I = 1,NZ
      AR(391,I) = 1.2E-11
      AR(392,I) = 4.4E-12*EXP(760./T(I))*0.25
      AR(393,I) = 5.5E-13*EXP(760./T(I))*0.25
      AR(394,I) = 4.4E-13*EXP(760./T(I))*0.25
      AR(395,I) = 1.1E-13*EXP(760./T(I))*0.25
      AR(396,I) = 1.9E-11*EXP(230./T(I))
      AR(397,I) = 5.8E-12*EXP(-1500./T(I))
      AR(398,I) = 1.2E-10*EXP(-430./T(I))
      AR(399,I) = 2.1E-11*EXP(240./T(I))
      AR(400,I) = 1.7E-11*EXP(250./T(I))
      AR(401,I) = 5.5E-12*EXP(200./T(I))
      AR(402,I) = 4.8E-12*EXP(-310./T(I))
      AR(403,I) = 1.0E-17
      AR(404,I) = 1.6E-11*EXP(-780./T(I))
      AR(405,I) = 1.0E-11*EXP(-3000./T(I))
      AR(406,I) = 1.6E-11
      AR(407,I) = 1.7E-11*EXP(-800./T(I))
      AR(408,I) = 2.6E-11*EXP(-1300./T(I))
      AR(409,I) = 8.8E-12*EXP(260./T(I))
      AR(410,I) = 9.5E-13*EXP(550./T(I))
      AR(411,I) = 2.4E-12*EXP(40./T(I))
      AR(412,I) = 2.8E-14*EXP(860./T(I))
      AR(413,I) = 1.0E-12
      AR(414,I) = 4.5E-12*EXP(500./T(I))*0.8
      AR(415,I) = 4.5E-12*EXP(500./T(I))*0.2
      AR(416,I) = 8.7E-12*EXP(260./T(I))
      AR(424,I) = 1.2E-10
c-JL COMPLETE SOME SULFUR,SINGLET O2 CHEMISTRY
      AR(425,I) = 3.0E-12*EXP(-8000./T(I))
      AR(426,I) = 1.0E-26
      AR(427,I) = 0.5*2.5E-15
      AR(428,I) = 0.5*2.5E-15
      AR(429,I) = 2.5E-16
      AR(430,I) = 3.3E-11*EXP(55./T(I))*0.8
      AR(431,I) = 3.3E-11*EXP(55./T(I))*0.2
      AR(432,I) = 5.2E-11*EXP(-2840./T(I))
      AR(433,I) = 8.0E-17
      AR(434,I) = 3.5E-11*EXP(-135./T(I))*0.9
      AR(435,I) = 4.0E-17
      AR(436,I) = 2.0E-17
      AR(437,I) = 4.2E-13
      AR(438,I) = 1.0E-20
      AR(439,I) = 1.9E-11*EXP(215./T(I))
      AR(446,I) = 4.9E-11
      AR(447,I) = 2.1E-11*EXP(-470./T(I))
      AR(448,I) = 5.9E-12*EXP(-170./T(I))
      AR(449,I) = 4.1E-13*EXP(290./T(I))
      AR(450,I) = 2.0E-12*EXP(-840./T(I))
      AR(451,I) = 1.46E-11*EXP(-1040./T(I))
      AR(452,I) = 6.8E-12*EXP(-830./T(I))
      AR(455,I) = 2.5E-13*EXP(-486./T(I))
      AR(456,I) = 5.5E-12*EXP(362./T(I))
      AR(457,I) = 1.3E-11
      AR(458,I) = 7.5E-13*EXP(-304./T(I))
      AR(459,I) = 1.5E-12*EXP(96./T(I))
      AR(460,I) = 1.3E-11*EXP(-975./T(I))
      AR(461,I) = 2.2E-12
      AR(462,I) = 3.6E-11
      AR(463,I) = 1.83E-11*EXP(253./T(I))
      AR(464,I) = 5.9E-23
      AR(465,I) = 1.0E-11
      AR(466,I) = 2.01E-15
      AR(467,I) = 1.65E-13*((T(I)/298.)**2.33)*EXP(-2116./T(I))
      AR(468,I) = 3.24E-12*EXP(-1120./T(I))
      AR(469,I) = 1.66E-10*EXP(-8210./T(I))
      AR(470,I) = 1.7E-12*EXP(-1215./T(I))
      AR(471,I) = 1.0E-11
      AR(472,I) = 1.66E-13*EXP(-12147./T(I))
      AR(473,I) = 1.45E-11
      AR(474,I) = 2.09E-11
      AR(475,I) = 3.32E-15           
   16 CONTINUE   
C ***** GIORGI AND CHAMEIDES RAINOUT RATE *****
      GAM15 = 8.64E+05/2.0
      GAM8 = 7.0E+06/2.0
      AV = 6.02E+23
      WL = 1.0
      R = 1.36E-22
      NH = ZTROP/DZ + 0.01

C  Loop over altitude
      DO 17 I=1,NH
      ZKM = Z(I)/1.E5
      TEMP = T(I)
C
C  Find appropriate GAMMA
      IF (ZKM.LE.1.51) THEN
         GAMMA = GAM15
      ELSE IF (ZKM.LT.8.) THEN
         GAMMA = GAM15 + (GAM8-GAM15)*((ZKM-1.5)/6.5)
      ELSE
         GAMMA = GAM8
      END IF
C
C  Find WH2O
      IF (ZKM.LE.1.) THEN
         X = 11.35 + 0.1*ZKM
      ELSE
         X = 11.5444 - 0.085333*ZKM - 9.1111E-03*ZKM*ZKM
      END IF
      WH2O = 10.0**X
C
C  Find F(Z)
      IF (ZKM.LE.1.51) THEN
         F = 0.1
      ELSE
         F = 0.16615 - 0.04916*ZKM + 3.37451E-03*ZKM*ZKM
      END IF
C
C  Loop over species
      DO 17 J=1,NQ
      RKJ = (WH2O/55.)/(AV*WL*1.0E-9 + 1./(H(J)*R*TEMP))
      QJ = 1. - F + F/(GAMMA*RKJ) * (1.0 - EXP(-RKJ*GAMMA))
  17  RAINGC(J,I) = (1. - EXP(-RKJ*GAMMA))/(GAMMA*QJ)
C
      NH1 = NH + 1
      DO 18 I=NH1,NZ
      DO 18 J=1,NQ
  18  RAINGC(J,I) = 0.
C
C ***** RAINOUT RATE *****
      DO 19 I=1,NZ
      ZKM = Z(I)/1.E5
      RAIN(I) = 0.
      IF(ZKM.LT.10.) RAIN(I) = 2.4E-6*EXP((6. - ZKM)/2.42)
      IF(ZKM.LT.6.) RAIN(I) = 2.4E-6
  19  CONTINUE

      RETURN
      END
