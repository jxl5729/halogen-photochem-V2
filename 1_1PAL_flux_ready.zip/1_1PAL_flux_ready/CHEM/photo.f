
      SUBROUTINE PHOTO(ZY,AGL,LTIMES,ISEASON,IZYO2,IO2,INO,N)
      
      INCLUDE '../INCLUDECHEM/parNZ.inc'
      INCLUDE '../INCLUDECHEM/parNQ_NQT.inc'
      INCLUDE '../INCLUDECHEM/parNR.inc'
      INCLUDE '../INCLUDECHEM/parNSP_NSP1_NSP2.inc'
      INCLUDE '../INCLUDECHEM/parNMAX.inc'
 
      DIMENSION SO2(NZ),SO3(NZ),SIGL(NZ),SIGNOL(NZ),CL(NZ),
     2  CNO(NZ),D0(2),WAV(108),XL(10),FFDN(101),FRO2(10)
      dimension S1(10)!!SS(108) 

      INCLUDE '../INCLUDECHEM/comABLOK.inc'
      INCLUDE '../INCLUDECHEM/comCBLOK.inc'
      INCLUDE '../INCLUDECHEM/comQBLOK.inc'
      INCLUDE '../INCLUDECHEM/comRBLOK.inc'
      INCLUDE '../INCLUDECHEM/comSBLOK.inc'
      INCLUDE '../INCLUDECHEM/comTBLOK.inc'
      INCLUDE '../INCLUDECHEM/comO3BLOK.inc'
      INCLUDE '../INCLUDECHEM/comFLUXPHOTO.inc'
c-AJ/JL: ADD CORRELATED K TABLE
      INCLUDE '../INCLUDECHEM/parCORRK.inc'        
      INCLUDE '../INCLUDECHEM/comCORRK.inc'     
       data XL/1725.,1675.,1625.,1575.,1525.,1475.,1425.,1375.,
     & 1325.,1216./
c       
c- AJ/JL: Add quantum yield for far UV loop
      data FRO2/1.,1.,1.,1.,1.,1.,1.,0.22,0.61,0.56/       
C
      PM = 1.67E-24
      BK = 1.38E-16
      RGAS = 8.3143E7
      WT = O2(1)*32. + CO2(1)*44. + (1.-O2(1)-CO2(1))*28. + 0.4
      RMG = RGAS/(WT*G)
      PI = 3.14159
      ZYR = ZY*PI/180.
      U0 = COS(ZYR)
      AM = 1./U0
      NZ1 = NZ - 1
      NZZ1 = NZ + 1
      RO3 = 0.9
      D0(1) = 1.2E-6
      D0(2) = 2.6E-6
      ALNO = 5.1E7
      QKNO = 1.5E-9
      DIJ = 1.65E9
      NPHOT = NPHOT + 1
      HC = 6.625E-27 * 3.00E10

      IF (N.EQ.1) write(90,119)
 119  FORMAT(/1X,'ENERGY FLUXES IN W/m^2/nm and photons/m^2/s/nm
     &  (NOT DIURNALLY AVERAGED)')
      IF (N.eq.1) write(90,118)
 118  FORMAT(/2X,'L',6X,'WAV',10X,'EFLUX',9X,'GFLUX',
     & 10X,'S(1)',8x,'PhEFLUX',8x,'PhGFLUX')
      
C ***** SET PHOTOLYSIS RATES TO ZERO *****
      DO 1 I=1,NZ
      PO2(I) = 0.
      PO3(I) = 0.
      PO3D(I) = 0.
      PH2O(I) = 0.
      PH2O2(I) = 0.
      PCO2(I) = 0.
      PCO2D(I) = 0.
      PHCO(I) = 0.
      PH2(I) = 0.
      PO2D(I) = 0.
      PHO2(I) = 0.
      PCH4(I) = 0.
      PMOOH(I) = 0.
      PN2O(I) = 0.
      PHNO3(I) = 0.
      PNO(I) = 0.
      PNO2(I) = 0.
      PHNO4(I) = 0.
      PCCL3F(I) = 0.
      PCCL2F2(I) = 0.
      PCCL4(I) = 0.
      PCH3CL(I) = 0.
      PMCCL3(I) = 0.
      PCL2(I) = 0.
      PCLO2(I) = 0.
      PHCL(I) = 0.
      PHOCL(I) = 0.
      PNOCL(I) = 0.
      PCLONO(I) = 0.
      PCLONO2(I) = 0.
      pno3(i) = 0.
      pn2o5(i) = 0.
      pcl2o2(i) = 0.
C-AP
      PSO2(I) = 0.
      PSO21(I) = 0.
      PSO23(I) = 0.
      PSO(I) = 0.
      PH2S(I) = 0.
      PH2SO4(I) = 0.
C-JL ADDING IODINE PHOTOCHEMISTRY
      PCH3I(I) = 0.
      PCH2I2(I) = 0.
      PCH2ICL(I) = 0.
      PI2(I) = 0.
      PIO(I) = 0.
      PXIO2(I) = 0.
      PIH(I) = 0. 
      PINO(I) = 0. 
      PINO2(I) = 0. 
      PINO31(I) = 0.
      PINO32(I) = 0.
      PIHO(I) = 0.
      PICL(I) = 0.
c-JL ADDING BROMINE 
      PBRO2(I) = 0.
      PHOBR1(I) = 0.
      PHOBR2(I) = 0.
      PIBR(I) = 0.
      PBR2(I) = 0.
      PHBR(I) = 0. 
      PBRO(I) = 0.
      P1BRNO3(I) = 0.
      P2BRNO3(I) = 0.
      P1BRNO2(I) = 0.
      P2BRNO2(I) = 0.
      PCH3BR(I) = 0.
      PCH2BR2(I) = 0.
      FDNTOTAL(I) = 0.
      FDNTOTAL(101) = 0.
c-JL: add two more SO3 photolysis
      PSO31(I) = 0.
      PSO32(I) = 0.
   1  CONTINUE 
C
C ***** CALCULATE COLUMN DEPTHS ABOVE EACH COLLOCATION POINT FOR O2
C       (TOO) AND O3 (TO3).  ADD OTHER SPECIES HERE IF YOU WANT
C       ADDITIONAL MAJOR ABSORBERS. *****
      HA = RMG*T(NZ)
      HAD = HA*DEN(NZ)
      TTOT(NZ) = DEN(NZ)*HA
      TO2(NZ) = O2(NZ)*HAD
      TO3(NZ) = O3(NZ)*HAD
      TCO2(NZ) = CO2(NZ)*HAD
      TH2O(NZ) = H2O(NZ)*HAD
C-AP
      TSO2(NZ) = FSO2(NZ) * HAD
      TH2S(NZ) = H2S(NZ) * HAD
      TCH4(NZ) = CH4(NZ) * HAD
C-AP                                                 
      DO 2 M=1,NZ1
      I = NZ - M
      DZ = Z(I+1) - Z(I)
      HA = RMG*0.5*(T(I) + T(I+1))
      EFAC = (1. - EXP(-DZ/HA))*DEN(I)*HA
      TTOT(I) = TTOT(I+1) + EFAC
      TO2(I) = TO2(I+1) + EFAC*SQRT(O2(I)*O2(I+1))
      TO3(I) = TO3(I+1) + EFAC*SQRT(O3(I)*O3(I+1))
      TCO2(I) = TCO2(I+1) + EFAC*SQRT(CO2(I)*CO2(I+1))
      TH2O(I) = TH2O(I+1) + EFAC*SQRT(H2O(I)*H2O(I+1))
      TSO2(I) = TSO2(I+1) + EFAC*SQRT(FSO2(I)*FSO2(I+1))
      TH2S(I) = TH2S(I+1) + EFAC*SQRT(H2S(I)*H2S(I+1))
      TCH4(I) = TCH4(I+1) + EFAC*SQRT(CH4(I)*CH4(I+1))
c-AP                         
   2  CONTINUE
C
      IF(LTIMES.GT.0) GO TO 3          
C
C  SCALE FLUX(L) VALUES FOR SOLAR FLUX AT EARTH (FSCALE=1) OR
C  MARS (FSCALE=0.43).
C
      DO 800 L=1,108
  800  FLUX(L)=FLUX(L)*FSCALE
        
C   CALCULATE N2O5 CROSS SECTIONS AT LONG WAVELENGTHS
      DO 147 L=44,61
      WAVN = 0.5*(WAVL(L) + WAVU(L))/10.
      TEMP = 250.
 147  SN2O5(L) = 1.E-20 * EXP(2.735 + ((4728.5 - 17.127*WAVN)/TEMP))
C
C   CALCULATE NO2 QUANTUM YIELDS
      DO 47 L=47,60
      WAVN = 0.5*(WAVL(L) + WAVU(L))/10.
  47  RNO2(L) = 1. - 8.E-4*(WAVN - 275.)
C
C ***** CALCULATE ALLEN AND FREDERICK SCHUMANN-RUNGE BAND COEFS *****
C-JK  Note: The A&F band model is no longer used. We continue to read in
C     the coefficients from the datafile, 'photos.pdat', though, to
C     make it easy for others to use this code. The coefficients for
C     nitric oxide predissociation are still used, however, so don't
C     delete this entire section without replacing them.      
   3  CONTINUE
      IF (LTIMES.GT.0 .AND. ISEASON.LT.3) GO TO 13
C
C   REPEAT THIS SECTION ONLY IF PRESSURE AND TEMPERATURE VARY WITH TIME
      DO 4 I=1,NZ
   4  PLOG(I) = ALOG10(DEN(I)*BK*T(I)/1.E3)
      CALL O3PHOT
C
      DO 5 L=1,17
      DO 6 I=1,NZ
   6  SIGL(I) = 0.
C
      IF (L.GE.15) GO TO 7
      DO 8 I=1,NZ
   8  BIGX(I) = PLOG(I)
      GO TO 9
   7  CONTINUE
      DO 10 I=1,NZ
  10  BIGX(I) = T(I)
C
   9  KMAX = KA(L)
      DO 11 K=1,KMAX
      DO 11 I=1,NZ
  11  SIGL(I) = SIGL(I) + A(L,K)*BIGX(I)**(K-1)
      DO 12 I=1,NZ
  12  SIG0(I,L) = 10.**SIGL(I)
   5  CONTINUE
C
C   COEFFICIENTS FOR NITROUS OXIDE (NO)
      DO 30 L=1,2
      DO 31 I=1,NZ
  31  SIGNOL(I) = 0.

      DO 32 K=1,9
      DO 32 I=1,NZ
  32  SIGNOL(I) = SIGNOL(I) + ANO(K,L)*PLOG(I)**(K-1)
      DO 33 I=1,NZ
  33  SIGNO0(I,L) = 10.**SIGNOL(I)
  30  CONTINUE
  13  CONTINUE
      IF(LTIMES.GT.0 .AND. IZYO2.LT.1) GO TO 14
C
C   REPEAT THIS SECTION ONLY IF SOLAR ZENITH ANGLE OR O2 VARIES
C   WITH TIME
      DO 39 I=1,NZ
  39  TO2L(I) = ALOG10(TO2(I))
      DO 15 L=1,17
      DO 16 I=1,NZ
  16  CL(I) = 0.
C
      KMAX = KB(L)
      DO 17 K=1,KMAX
      DO 17 I=1,NZ
  17  CL(I) = CL(I) + B(L,K)*TO2L(I)**(K-1)
C
      DO 18 I=1,NZ
      C = 10.**CL(I)
      SD = SIG0(I,L) * AM**(-C)
  18  SRO2(I,L) = AMIN1(SD,2.E-19)
  15  CONTINUE
C
C   COEFFICIENTS FOR NO
      DO 35 L=1,2
      DO 36 I=1,NZ
  36  CNO(I) = 0.
C
      DO 37 K=1,5
      DO 37 I=1,NZ
  37  CNO(I) = CNO(I) + BNO(K,L)*TO2L(I)**(K-1)
      DO 38 I=1,NZ
      SD = SIGNO0(I,L) * AM**CNO(I)
  38  SIGNO(I,L) = AMIN1(SD,1.E-15)
  35  CONTINUE
  14  CONTINUE
C
C ***** START SHORTWAVE LOOP (1754 - 2532 A) *****
C     Note: The first 17 bands (out of 35) contain the O2 Schumann-
C     Runge bands. This part has been updated to the new correlated-k
C     parameterization. Commented out lines refer to the old exponential
C     sum parameterization. These have been left in, so that one can
C     see where the new coefficients have replaced the old ones.      
      DO 19 L=1,35
c
      WRITE(100,*)
      WRITE(100,*)'L=',L
      WRITE(100,*)
      IF(L.NE.1 .AND. L.NE.10 .AND. L.NE.17) GO TO 1001
      WRITE(101,*)
      WRITE(101,*)'L = ',L
 1001 CONTINUE
c      
      IF (L.LE.17) GO TO 27
      DO 25 I=1,NZ
      SO3(I) = SO31(L)
  25  SO2(I) = SO2HZ(L)
      GO TO 28
C
  27  CONTINUE
      DO 26 I=1,NZ
      SO3(I) = SO31(L)
  26  SO2(I) = SO2HZ(L) + SRO2(I,L)
  28  CONTINUE
      SSO2T = SSO2(L) + SSO21(L)
      KN = 1
      ALP = 1.
c      IF (IO2.EQ.1 .AND. L.LE.17) KN = NK(L)
      IF (IO2.EQ.1 .AND. L.LE.17) KN = KNEW
C
      M=0
C   LOOP OVER K'S AT LOW O2 LEVELS
      DO 19 K=1,KN 
      IF (IO2.EQ.0) GO TO 20
      IF (L.GT.17) GO TO 66
c      ALP = ALPHA(L,K)!This is for exponential sum fits
      ALP = ALPHA(K) ! Correlated-k tables with 4 pts
c-JL: new print: 
      WRITE(100,401)K,ALP
  400 FORMAT(A,3X,1PE12.5)
  401 FORMAT('K=',I2,2X,'WEIGHT=',1PE10.3)
c      
      DO 65 I=1,NZ
c  65  SO2(I) = SO2HZ(L) + BETA(L,K)
  65  SO2(I) = SO2HZ(L) + BETA(K,L,I)
  300 FORMAT(I2,1PE12.5)
  301 FORMAT(A10,1PE12.5)      
  66  CONTINUE
C
C   SKIP MULTIPLE SCATTERING ROUTINE IF THE PURE ABSORPTION OPTICAL
C   DEPTH AT 20 KM IS MUCH GREATER THAN THE SCATTERING OPTICAL DEPTH
C   Note: We rarely use this option anymore, as the two-stream model
C   seems to have no problem handling high absorption optical depths.      
      WAV(L) = 0.5 * (WAVU(L) + WAVL(L))
      SIGR = SIGRAY(WAV(L)) * (1. + 1.5*CO2(1))
      TAURAY = SIGR * TTOT(20)
      TAUABS = SO2(20)*TO2(20) + SO3(20)*TO3(20) + SCO2(L)*TCO2(20)
     2  + SH2O(L)*TH2O(20) + SSO2T*TSO2(20) + SH2S(L)*TH2S(20)
      RATIO = TAUABS/TAURAY

      CALL TWOSTR(WAV(L),SIGR,U0,SO3,SO2,SCO2(L),SH2O(L),SSO2T,
     2 SH2S(L),FFDN)
      M=1
      GO TO 21
C
  20  CONTINUE
      TAU = SO2(NZ)*TO2(NZ) + SO3(NZ)*TO3(NZ) + SH2O(L)*TH2O(NZ)
     2  + SCO2(L)*TCO2(NZ)
      S(NZ) = EXP(-AM*TAU)
C
      DO 22 J=1,NZ1
      I = NZ - J
      SIGO2 = 0.5 * (SO2(I) + SO2(I+1))
      DTAU = SIGO2*(TO2(I) - TO2(I+1)) + SO3(I)*(TO3(I) - TO3(I+1))
     2  + SH2O(L)*(TH2O(I) - TH2O(I+1)) + SCO2(L)*(TCO2(I)
     3  - TCO2(I+1))
  22  S(I) = S(I+1) * EXP(-AM*DTAU)


  21  FLX = FLUX(L)*AGL*ALP
      ss(L) =s(1)

      DO 23 I=1,NZ
      PO2(I) = PO2(I) + FLX*SO2(I)*S(I)
      PO3D(I) = PO3D(I) + FLX*SO3(I)*RO3*S(I)
      PO3(I) = PO3(I) + FLX*SO3(I)*(1.-RO3)*S(I)
      PH2O(I) = PH2O(I) + FLX*SH2O(L)*S(I)
      PH2O2(I) = PH2O2(I) + FLX*SH2O2(L)*S(I)
      PCO2(I) = PCO2(I) + FLX*SCO2(L)*S(I)
      PHO2(I) = PHO2(I) + FLX*SHO2(L)*S(I)
      PHNO3(I) = PHNO3(I) + FLX*SHNO3(L)*S(I)
      PN2O(I) = PN2O(I) + FLX*SN2O(L)*S(I)
      PMOOH(I) = PMOOH(I) + FLX*SMOOH(L)*S(I)
      PNO2(I) = PNO2(I) + FLX*SNO2(L)*RNO2(L)*S(I)
      PHNO4(I) = PHNO4(I) + FLX*SHNO4(L)*S(I)
      PCCL3F(I) = PCCL3F(I) + FLX*SCCL3F(L)*S(I)
      PCCL2F2(I) = PCCL2F2(I) + FLX*SCCL2F2(L)*S(I)
      PCCL4(I) = PCCL4(I) + FLX*SCCL4(L)*S(I)
      PCH3CL(I) = PCH3CL(I) + FLX*SCH3CL(L)*S(I)
      PMCCL3(I) = PMCCL3(I) + FLX*SMCCL3(L)*S(I)
      PCL2(I) = PCL2(I) + FLX*SCL2(L)*S(I)
      PCLO2(I) = PCLO2(I) + FLX*SCLO2(L)*S(I)
      PHCL(I) = PHCL(I) + FLX*SHCL(L)*S(I)
      PHOCL(I) = PHOCL(I) + FLX*SHOCL(L)*S(I)
      PNOCL(I) = PNOCL(I) + FLX*SCLNO(L)*S(I)
      PCLONO(I) = PCLONO(I) + FLX*SCLONO(L)*S(I)
      PCLONO2(I) = PCLONO2(I) + FLX*SCLONO2(L)*S(I)
      pn2o5(i) = pn2o5(i) + flx*sn2o5(l)*s(i)
      pcl2o2(i) = pcl2o2(i) + flx*scl2o2(l)*s(i)
      PSO2(I) = PSO2(I) + FLX*SSO2(L)*S(I)
      PSO21(I) = PSO21(I) + FLX*SSO21(L)*S(I)
c     PSO(I) = PSO(I) + FLX*SSO(L)*S(I)
      PH2S(I) = PH2S(I) + FLX*SH2S(L)*S(I)
      PH2SO4(I) = PH2SO4(I) + FLX*SHCL(L)*S(I)
C-JL
      PCH3I(I) = PCH3I(I) + FLX*SCH3I(L)*S(I)
      PCH2I2(I) = PCH2I2(I) + FLX*SCH2I2(L)*S(I)/3.!temperature effects
      PINO(I) = PINO(I) + FLX*SINO(L)*S(I)
      PINO2(I) = PINO2(I) + FLX*SINO2(L)*S(I)
      PINO31(I) = PINO31(I) + FLX*SINO31(L)*S(I)
      PINO32(I) = PINO32(I) + FLX*SINO32(L)*S(I)
      PIH(I) = PIH(I) + FLX*SIH(L)*S(I)
      PIO(I) = PIO(I) + FLX*SIO(L)*S(I)*(2.0728-3.6E-3*T(I))!Bloss2001
c      PIO(I) = PIO(I) + FLX*SIO(L)*S(I)*(5.8574-1.63E-2*T(I))!Sander86       
      PCH2ICL(I) = PCH2ICL(I) + FLX*SCH2ICL(L)*S(I)
      PIHO(I) = PIHO(I) + FLX*SIHO(L)*S(I)
      PICL(I) = PICL(I) + FLX*SICL(L)*S(I)
c      PXIO2(I) = PXIO2(I) + FLX*SXIO2(L)*S(I)
      PI2(I) = PI2(I) + FLX*SI2(L)*S(I)
      PBRO2(I) = PBRO2(I)+FLX*SBRO2(L)*S(I)      
      PHOBR1(I) = PHOBR1(I)+FLX*SHOBR1(L)*S(I)      
      PHOBR2(I) = PHOBR2(I)+FLX*SHOBR2(L)*S(I)      
      PIBR(I) = PIBR(I)+FLX*SIBR(L)*S(I)      
      PBR2(I) = PBR2(I)+FLX*SBR2(L)*S(I)      
      PHBR(I) = PHBR(I)+FLX*SHBR(L)*S(I)      
      PBRO(I) = PBRO(I)+FLX*SBRO(L)*S(I)
      P1BRNO3(I) = P1BRNO3(I)+FLX*S1BRNO3(L)*S(I)
      P2BRNO3(I) = P2BRNO3(I)+FLX*S2BRNO3(L)*S(I)
      P1BRNO2(I) = P1BRNO2(I)+FLX*S1BRNO2(L)*S(I)
      P2BRNO2(I) = P2BRNO2(I)+FLX*S2BRNO2(L)*S(I)
      PCH3BR(I) = PCH3BR(I)+FLX*SCH3BR(L)*S(I)
      PCH2BR2(I) = PCH2BR2(I)+FLX*SCH2BR2(L)*S(I)
c
      PSO31(I) = PSO31(I)+FLX*SSO31(L)*S(I)
      PSO32(I) = PSO32(I)+FLX*SSO31(L)*S(I)      
  23  CONTINUE

      DO I = 1,NZZ1 
      FDNTOTAL(I) = FDNTOTAL(I)+FFDN(I)*FLX 
      end do 


C-AP    
c PRinting the source function for each wavelength
       WAV(L) = 0.5 * (WAVU(L) + WAVL(L))
c     write(*,'(A,I4,2x,F8.1)')'wavelength ',L, WAV(L)
c      do i=1,NZ
c       write(*,'(I4,E10.3)')i,S(i)
c      enddo 

      IF (N.EQ.0) GO TO 72
      IF(L.LE.17 .AND. K.LT.KN) GO TO 72
       TAUR = SIGR*TTOT(1)
       DELWAV = WAVU(L) - WAVL(L)
c  Here the flux is converted from photons/cm^2/s to W/m^2/nm
c  cm^ converted to m^2 (1e4 factor)
c  HC/lambda in cgs converted to Joules (1e7 factor)
c  WAV converted from Angstrongs to cm (1e8 factor)
c  DELWAV converted from Angstrongs to nanometers (1e-1 factor)
c      EFLUX(L) = (HC*1.e8/WAV(L))*(1.e4/1.e7)*FLUX(L)/
c     & ((1.e-1*DELWAV))
c      GFLUX(L) = EFLUX(L)*S(1)
c Converting FLUX from photons/cm^2/s to photons/m^2/s/nm
c      PhEFLUX(L) = 1.e4*FLUX(L)/((1.e-1*DELWAV))
c      PhGFLUX(L) = PhEFLUX(L)*S(1)
c      write(90,120) L,WAV(L),TAUR,EFLUX(L),GFLUX(L),
c     & S(1),PhEFLUX(L),PhGFLUX(L)
  72  CONTINUE
C
C   NO PREDISSOCIATION IN THE D00 (1910 A) AND D10 (1830 A) BANDS
      NOL = LLNO(L)
      IF (NOL.EQ.0) GO TO 19
      IF (INO.EQ.1) GO TO 48
c      print *, ' PO3D(1)',PO3D(1)
C
C   FREDERICK AND ALLEN METHOD (EFFECTIVE CROSS SECTIONS)
      DO 40 I=1,NZ
  40  PNO(I) = PNO(I) + FLX*SIGNO(I,NOL)*S(I)
      GO TO 19
c
C
C   OLD (CIESLIK AND NICOLET) METHOD WITH INTENSITIES UPDATED TO
C   FREDERICK AND HUDSON (1979)
  48  CONTINUE
      DO 49 I=1,NZ
      RN2 = DIJ/(ALNO + DIJ + QKNO*DEN(I))
  49  PNO(I) = PNO(I) + 0.5*D0(NOL)*S(I)*RN2*AGL*ALP 
    
  19  CONTINUE
c      print *, ' PO3D(1)',PO3D(1)
C ***** END SHORTWAVE LOOP *****

      DO 60 I=1,NZ
  60  SO2(I) = 0.


c      print *, ' PO3D(1)',PO3D(1)
C ***** START LONGWAVE LOOP (2532 - 8550 A) *****
      DO 57 L=36,108
c      print *, 'L =',L,' PO3D(1)',PO3D(1)
      IF (L.LT.39 .OR. L.GT.59) GO TO 61
C


      DO 29 I=1,NZ
      TI = AMAX1(T(I),203.)
      TI = AMIN1(T(I),273.)
      FR = (TI - 203.)/70.
c April 2025 JL: add temperature dependence for IO
c      SIO(I) = SIO(I)*((2.0-3.6E-3*T(I))/288.)
c      print *, 'so31 =', so31 all the same
  29  SO3(I) = FR*SO32(L) + (1.-FR)*SO31(L)
      GO TO 64
C
  61  CONTINUE
      DO 63 I=1,NZ
  63  SO3(I) = SO31(L)
c      
  64  SSO2T = 0.
      SH2SL = 0.
      IF (L.GT.68) GO TO 165
      SSO2T = SSO21(L) + SSO23(L)
      SH2SL = SH2S(L)
 165  CONTINUE
C
C   SKIP MULTIPLE SCATTERING ROUTINE IF THE PURE ABSORPTION OPTICAL
C   DEPTH AT 20 KM IS MUCH GREATER THAN THE SCATTERING OPTICAL DEPTH
      WAV(L) = 0.5 * (WAVU(L) + WAVL(L))
      SIGR = SIGRAY(WAV(L)) * (1. + 1.5*CO2(1))
      TAURAY = SIGR*TTOT(20)
      TAUABS = SO3(20)*TO3(20) + SSO2T*TSO2(20) + SH2SL*TH2S(20)
      RATIO = TAUABS/TAURAY
C-AP Always do TWOSTR
C-AP      IF (RATIO.GT.5.) GO TO 51
      CALL TWOSTR(WAV(L),SIGR,U0,SO3,SO2,0.,0.,SSO2T,SH2SL,FFDN)
c      print *, ' PO3D(I)',PO3D(I)
      GO TO 52
 
C
  51  CONTINUE
      TAU = SO3(NZ)*TO3(NZ)
      S(NZ) = EXP(-AM*TAU)
C
      DO 53 J=1,NZ1
      I = NZ - J
      SIGO3 = 0.5 * (SO3(I) + SO3(I+1))
 
      DTAU = SIGO3 * (TO3(I) - TO3(I+1))
  53  S(I) = S(I+1) * EXP(-AM*DTAU)
C
c      print *, ' SO3 = ' ,SO3 
c      print *, 'J =', J

  52  FLX = FLUX(L)*AGL
c-JL replace SS with net downward flux
c      SS(L) = s(1)
      SS(L) = FNETDN(1)
c   Calculate values for Whittet plots
      wav(l) = 0.5*(wavl(l) + wavu(l))

c      if(L.eq.52) print *,'In PHOTO, AT, BT,CT,WAV,ALMO,RO3,T'
      DO 54 I=1,NZ
      BL = BT(I)*(0.1*WAV(L) - ALM0(I))
      RO3 = AT(I)*ATAN(BL) + CT(I)
      RO3 = AMAX1(RO3,0.)
      RO3 = AMIN1(RO3,0.9)
c      if(L.eq.52) Print 1500,AT(I), BT(I),CT(I),WAV(L),ALM0(I),
c     2  RO3,T(I)
c 1500 format(1x,1p7e10.3)
      PO3D(I) = PO3D(I) + FLX*SO3(I)*RO3*S(I)
      PO3(I) = PO3(I) + FLX*SO3(I)*(1.-RO3)*S(I)
      PXIO2(I) = PXIO2(I) + FLX*SXIO2(L)*S(I)
c       print *, ' BT(I) = ', BT(I)
c      print *, 'BL = ', BL 
c      print *, ' PO3D(I)',PO3D(I)

c       print *, 'flx = ',flx
c       print *, 'SO3(I) = ', SO3(I)  
c       print *, 'RO3 = ', RO3  
c       print *, ' S(I) =', S(I)  
 54   CONTINUE
c
      IF(L.NE.68) GO TO 170
C   Set NO3 photorate at this wavelength. Reduce the rate by 'fudge'
C   to simulate nighttime chemistry
      fudge = 0.25
      DO 169 I=1,NZ
 169  PNO3(I) = 0.18 * AGL * S(I)/S(NZ) * fudge
 170  CONTINUE
C
      IF (L.GT.68) GO TO 57
c      print *, 'SIO2 ='
c      print *, SIO2
      DO 55 I=1,NZ
      PH2O2(I) = PH2O2(I) + FLX*SH2O2(L)*S(I)
      PHCO(I) = PHCO(I) + FLX*SH2CO(L)*RHCO(L)*S(I)
      PH2(I) = PH2(I) + FLX*SH2CO(L)*RH2(L)*S(I)
      PHNO3(I) = PHNO3(I) + FLX*SHNO3(L)*S(I)
      PMOOH(I) = PMOOH(I) + FLX*SMOOH(L)*S(I)
      PNO2(I) = PNO2(I) + FLX*SNO2(L)*RNO2(L)*S(I)
      PHNO4(I) = PHNO4(I) + FLX*SHNO4(L)*S(I)
      PCCL3F(I) = PCCL3F(I) + FLX*SCCL3F(L)*S(I)
      PCCL4(I) = PCCL4(I) + FLX*SCCL4(L)*S(I)
      PCL2(I) = PCL2(I) + FLX*SCL2(L)*S(I)
      PCLO2(I) = PCLO2(I) + FLX*SCLO2(L)*S(I)
      PHOCL(I) = PHOCL(I) + FLX*SHOCL(L)*S(I)
      PNOCL(I) = PNOCL(I) + FLX*SCLNO(L)*S(I)
      PCLONO(I) = PCLONO(I) + FLX*SCLONO(L)*S(I)
      PCLONO2(I) = PCLONO2(I) + FLX*SCLONO2(L)*S(I)
      pn2o5(i) = pn2o5(i) + flx*sn2o5(l)*s(i)
      pcl2o2(i) = pcl2o2(i) + flx*scl2o2(l)*s(i)
C-AP
      PSO21(I) = PSO21(I) + FLX*SSO21(L)*S(I)
      PSO23(I) = PSO23(I) + FLX*SSO23(L)*S(I)
      PH2S(I) = PH2S(I) + FLX*SH2S(L)*S(I)
C-JL
      PCH3I(I) = PCH3I(I) + FLX*SCH3I(L)*S(I)
      PCH2I2(I) = PCH2I2(I) + FLX*SCH2I2(L)*S(I)/3.!temperature effect
      PINO(I) = PINO(I) + FLX*SINO(L)*S(I)
      PINO2(I) = PINO2(I) + FLX*SINO2(L)*S(I)
      PINO31(I) = PINO31(I) + FLX*SINO31(L)*S(I)
      PINO32(I) = PINO32(I) + FLX*SINO32(L)*S(I)
      PIH(I) = PIH(I) + FLX*SIH(L)*S(I)
      PIO(I) = PIO(I) + FLX*SIO(L)*S(I)*(2.0728-3.6E-3*T(I))!Bloss 2001
c      PIO(I) = PIO(I) + FLX*SIO(L)*S(I)*(5.8574-1.63E-2*T(I))!Sander86      
      PCH2ICL(I) = PCH2ICL(I) + FLX*SCH2ICL(L)*S(I)
      PIHO(I) = PIHO(I) + FLX*SIHO(L)*S(I)
      PICL(I) = PICL(I) + FLX*SICL(L)*S(I)
c      PXIO2(I) = PXIO2(I) + FLX*SXIO2(L)*S(I)
      PI2(I) = PI2(I) + FLX*SI2(L)*S(I)
      PBRO2(I) = PBRO2(I)+FLX*SBRO2(L)*S(I)      
      PHOBR1(I) = PHOBR1(I)+FLX*SHOBR1(L)*S(I)      
      PHOBR2(I) = PHOBR2(I)+FLX*SHOBR2(L)*S(I)      
      PIBR(I) = PIBR(I)+FLX*SIBR(L)*S(I)      
      PBR2(I) = PBR2(I)+FLX*SBR2(L)*S(I)      
      PHBR(I) = PHBR(I)+FLX*SHBR(L)*S(I)      
      PBRO(I) = PBRO(I)+FLX*SBRO(L)*S(I)
      P1BRNO3(I) = P1BRNO3(I)+FLX*S1BRNO3(L)*S(I)
      P2BRNO3(I) = P2BRNO3(I)+FLX*S2BRNO3(L)*S(I)
      P1BRNO2(I) = P1BRNO2(I)+FLX*S1BRNO2(L)*S(I)
      P2BRNO2(I) = P2BRNO2(I)+FLX*S2BRNO2(L)*S(I)
      PCH3BR(I) = PCH3BR(I)+FLX*SCH3BR(L)*S(I)
      PCH2BR2(I) = PCH2BR2(I)+FLX*SCH2BR2(L)*S(I)
c
      PSO31(I) = PSO31(I)+FLX*SSO31(L)*S(I)
      PSO32(I) = PSO32(I)+FLX*SSO31(L)*S(I)      
c      IF (L .Ne.75) go to 55 
c      print *,'I =',I
c      print *,'SXIO2 =',SXIO2(L)
c      print *,'PXIO2 =',PXIO2(I)
  55  CONTINUE
c      print *,'within photo,long-Wav'
c      print *, ' PIO2=',PXIO2
c      print *, 'SIO2 =',SXIO2
c      print *, 'S(I) =',S
c      print *, 'FLX =',FLX
c      stop

      DO I = 1,NZZ1
      FDNTOTAL(I) = FDNTOTAL(I)+FFDN(I)*FLX 
      end do

c      print *,'FFDN =',FFDN

c PRinting the source function for each wavelength
c      write(*,'(A,I4,2x,F8.1)')'wavelength ',L,WAV(L)
c      do i=1,NZ
c       write(*,'(I4,E10.3)')i,S(i)
c      enddo

       IF (N.EQ.0) GO TO 57
       TAUR = SIGR*TTOT(1)
       DELWAV = WAVU(L) - WAVL(L)

c  Here the flux is converted from photons/cm^2/s to W/m^2/nm
c  cm^ converted to m^2 (1e4 factor)
c  HC/lambda in cgs converted to Joules (1e7 factor)
c  WAV converted from Angstrongs to cm (1e8 factor)
c  DELWAV converted from Angstrongs to nanometers (1e-1 factor)
c      EFLUX(L) = (HC*1.e8/WAV(L))*(1.e4/1.e7)*FLX/((1.e-1*DELWAV)*AGL)
c      GFLUX(L) = EFLUX(L)*S(1)
c Converting FLUX from photons/cm^2/s to photons/m^2/s/nm
c      PhEFLUX(L) = 1.e4*FLX/((1.e-1*DELWAV)*AGL)
c      PhGFLUX(L) = PhEFLUX(L)*S(1)

c      IF (L.EQ.1) write(90,118)
c      write(90,120) L,WAV(L),TAUR,EFLUX(L),
c     & GFLUX(L),S(1),PhEFLUX(L),PhGFLUX(L)
c 120  FORMAT(1X,I2,2X,1P7E14.5)
C-AP
  57  CONTINUE
c      print *,'within photo,long-Wav'
c      print *, ' PIO2=',PXIO2
c      print *, 'SIO2 =',SXIO2
C ***** FAR UV (1216 - 1750 A) *****
      IF (LTIMES.GT.0) GO TO 62

C  SCALE SFX(L) VALUES FOR SOLAR FLUX AT EARTH (FSCALE=1) OR
C  MARS (FSCALE=0.43)
      DO 900 L=1,10
  900 SFX(L)=SFX(L)*FSCALE
C-AP
  62  CONTINUE
C
c-as Methane has been added as major absorber (03/24/2004)
      DO 50 L=1,10
      DO 50 I=1,NZ
      QQ = SFX(L)*50.*EXP(-(SIGMA(1,L)*TO2(I) + SIGMA(2,L)*TCO2(I)
     &  +SIGMA(3,L)*TH2O(I)+SSO2A(L)*TSO2(I)+SCH4(L)*TCH4(I))*AM)
      if(i.eq.1) s1(L)=QQ/(SFX(L)*50.)
      PO2D(I) = PO2D(I) + QQ*SIGMA(1,L)*AGL
      PCO2D(I) = PCO2D(I) + QQ*SIGMA(2,L)*AGL
      PH2O(I) = PH2O(I) + QQ*SIGMA(3,L)*AGL
C-AP
      PSO2(I) = PSO2(I) + QQ*SSO2A(L)*AGL
c     PSO(I) = PSO(I) + QQ*SSOA(L)*AGL
      PCH4(I) = PCH4(I) + QQ*SCH4(L)*AGL    
  50  CONTINUE
C
C ***** FILL UP RATE MATRIX *****
C   Note: This is where the photorates were loaded into the rate
C   constant matrix in the old code. This is now done in the main
C   code, following the call to subroutine PHOTO.
**********************************
C ***** FILL UP RATE MATRIX *****
c      DO 56 I=1,NZ
c      AR(23,I) = PO2D(I)
c      AR(24,I) = PO2(I)
c      AR(25,I) = PH2O(I)
c      AR(26,I) = PO3D(I)
c      AR(27,I) = PO3(I)
c      AR(28,I) = PH2O2(I)
c      AR(29,I) = PCO2(I)
c      AR(38,I) = PH2(I)
c      AR(39,I) = PHCO(I)
c      AR(42,I) = PCO2D(I)
c      AR(50,I) = PHO2(I)
c      AR(51,I) = PCH4(I)
c      AR(52,I) = PMOOH(I)
c      AR(53,I) = PN2O(I)
c      AR(54,I) = 1.7E-3
c      AR(55,I) = PHNO3(I)
c      AR(56,I) = PNO(I)
c      AR(57,I) = PNO2(I)
c      AR(95,I) = PHNO4(I)
c      AR(101,I) = PCH3CL(I)
c      AR(132,I) = PCL2(I)
c      AR(133,I) = PCLO2(I)
c      AR(134,I) = PHCL(I)
c      AR(135,I) = PHOCL(I)
c      AR(136,I) = PNOCL(I)
c      AR(137,I) = PCLONO(I)
c      AR(138,I) = PCLONO2(I)
c      AR(142,I) = PCL2O2(I)
c      AR(151,I) = PNO3(I)
c      AR(153,I) = PN2O5(I)
C-AP**********************************
C-AP Adding Sulfur photochemistry
c      AR(156,I) = 0.
c      AR(157,I) = 0.7*PSO2(I)
c      AR(158,I) = PH2S(I)
c      AR(186,I) = PSO21(I)
c      AR(187,I) = PSO23(I)
c      AR(188,I) = PH2SO4(I)
c      AR(189,I) = 0.
c      AR(211,I) = PHO2(I)
C-KK	The following reaction has been renumbered from 218 to 182
c      AR(182,I) = 0.3*PSO2(I)
c-JL ADD IODINE PHOTOLYSIS 
c      AR(260,I) = PCH3I(I)
c      AR(261,I) = PCH2I2(I)!/3.!divide to approx.low Temperature
c      AR(262,I) = PCH2ICL(I)
c      AR(263,I) = PI2(I)
c      AR(264,I) = PIO(I)
c      AR(265,I) = PXIO2(I)
c      AR(266,I) = PIH(I)
c      AR(267,I) = PINO(I)
c      AR(268,I) = PINO2(I)*0.5
c      AR(269,I) = PINO31(I)
c      AR(292,I) = PINO32(I)
c      AR(270,I) = PIHO(I)
c      AR(271,I) = PICL(I)
c      AR(291,I) = 0.5*PINO2(I)
c      AR(417,I) = PBR2(I)
c      AR(418,I) = PHBR(I) 
c      AR(419,I) = PBRO(I)
c      AR(420,I) = PBRO2(I)
c      AR(421,I) = PHOBR1(I)
c      AR(422,I) = PHOBR2(I)
c      AR(423,I) = PIBR(I)
c      AR(441,I) = P1BRNO3(I)
c      AR(442,I) = P2BRNO3(I)
c      AR(444,I) = P1BRNO2(I)
c      AR(445,I) = P2BRNO2(I)
c      AR(453,I) = PCH3BR(I)
c      AR(454,I) = PCH2BR2(I)
C-AP**********************************
c  56  CONTINUE


      if(N.eq.1) then
c Notice that for the 10 intervasl in the far UV SFX is in
c  photons/s/cm^2/A    
      do L1=10,1,-1      
      ESFX(L1) = (HC*1.e8/XL(L1))*(1.e4/1.e7)*SFX(L1)/1.e-1
      if(l1.eq.10) ESFX(L1)=(HC*1.e8/XL(L1))*(1.e4/1.e7)*
     & SFX(L1)*50.
      GSFX(L1) = ESFX(L1)*S1(L1)
c Converting FLUX from photons/cm^2/s to photons/m^2/s/nm
      PhESFX(L1) = 1.e4 *SFX(L1)/1.e-1
      if(l1.eq.10)PhESFX(L1)=1.e4 *SFX(L1)
      PhGSFX(L1) = PhESFX(L1)*S1(L1)
c      write(90,120) L1,XL(L1),ESFX(L1),GSFX(L1),
c     & S1(L1),PhESFX(L1),PhGSFX(L1)
      enddo

      do L=1,108
      DELWAV = WAVU(L) - WAVL(L)
      WAV(L) = 0.5 * (WAVU(L) + WAVL(L))
c  Here the flux is converted from photons/cm^2/s to W/m^2/nm
c  cm^ converted to m^2 (1e4 factor)
c  HC/lambda in cgs converted to Joules (1e7 factor)
c  WAV converted from Angstrongs to cm (1e8 factor)
c  DELWAV converted from Angstrongs to nanometers (1e-1 factor)
c      EFLUX(L) = (HC*1.e8/WAV(L))*(1.e4/1.e7)*FLUX(L)/
c     & (1.e-1*DELWAV)
c      GFLUX(L) = EFLUX(L)*SS(L)
c      GFLUXT(L)= GFLUX(L)*(DELWAV/10.)
c-JL 
      EFLUX(L) = (HC*1.e8/WAV(L))*(1.e4/1.e7)*FLUX(L)!*U0
c      GFLUX(L) = EFLUX(L)*FDNTOTAL(NZZ1)
      GFLUX(L) = EFLUX(L)*SS(L)

c      print *, 'Gflux(108) =', GFLUX(108) 
c      print *, 'SS =', SS 
c       print *, 'eflux = ', eflux 
c Converting FLUX from photons/cm^2/s to photons/m^2/s/nm
      PhEFLUX(L) = 1.e4*FLUX(L)/(1.e-1*DELWAV)
      PhGFLUX(L) = PhEFLUX(L)*SS(L)
      write(90,120) L,WAV(L),EFLUX(L),GFLUX(L),
     & SS(L),PhEFLUX(L),PhGFLUX(L)
      enddo
 120  FORMAT(1X,I3,2x,F7.1,2X,1P5E14.5)
      endif

c      UVC = GFLUX(14)+GFLUX(15)+GFLUX(16)+GFLUX(17)+GFLUX(18)+GFLUX(19)
c     2 +GFLUX(20)+GFLUX(21)+GFLUX(22)+GFLUX(23)+GFLUX(24)+GFLUX(25)
c     3 +GFLUX(26)+GFLUX(27)+GFLUX(28)+GFLUX(29)+GFLUX(30)+GFLUX(31)
c     4 +GFLUX(32)+GFLUX(33)+GFLUX(34)+GFLUX(35)+GFLUX(36)+GFLUX(37)
c     5 +GFLUX(38)+GFLUX(39)+GFLUX(40)+GFLUX(41)+GFLUX(42)+GFLUX(43)
c      UVB = GFLUX(43)+GFLUX(44)+GFLUX(45)+GFLUX(46)+GFLUX(47)+GFLUX(48)
c     2 +GFLUX(49)+GFLUX(50)+GFLUX(51)
c      UVA = GFLUX(51)+GFLUX(52)+GFLUX(53)+GFLUX(54)+GFLUX(55)+GFLUX(56)
c     2 +GFLUX(57)+GFLUX(58)+GFLUX(59)+GFLUX(60)+GFLUX(61)+GFLUX(62)
c     3 +GFLUX(63)
c      write(90,121) UVC
c 121  FORMAT(//1X,'UV-C(w/m2) at surface = ',1PE11.4)
c      write(90,122) UVB
c 122  FORMAT(//1X,'UV-B(w/m2) at surface = ',1PE11.4)
c      write(90,123) UVA
c 123  FORMAT(//1X,'UV-A(w/m2) at surface = ',1PE11.4)

      LTIMES = LTIMES + 1
      
c      print *,'FUP(1) =',FUP(1)
c      print *,'FDN(1) =',FDN(1) 
      RETURN


      END








