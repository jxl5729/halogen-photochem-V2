
      SUBROUTINE CHEMPL(D,XP,XL,K)

      INCLUDE '../INCLUDECHEM/parNZ.inc'
      INCLUDE '../INCLUDECHEM/parNQ_NQT.inc' 
      INCLUDE '../INCLUDECHEM/parNR.inc'
      INCLUDE '../INCLUDECHEM/parNSP_NSP1_NSP2.inc'
      INCLUDE '../INCLUDECHEM/parNMAX.inc'    
      
      DIMENSION XP(NZ),XL(NZ),D(NSP2,NZ)

      INCLUDE '../INCLUDECHEM/comRBLOK.inc'
C-JL THIS SUBROUTINE CALCULATES CHEMICAL PRODUCTION AND LOSS RATES 
C    USING THE INFO IN THE MATRICES JCHEM,IPROD AND ILOSS. THIS 
C    SUBROUTINE IS CALLED BY DOCHEM. 
C   
c      print *, 'K =', K
c      print *, 'D = '
c      print *, (D(1,I),I= 1,NZ) 
c      print *, 'CHEMPL-CHEMICAL LOSS MATRIX,CHEMPL'
c      DO J = 1,NSP
c      print 601,J, (ILOSS(1,J,M),M = 1,30)
c      end do
c      DO J = 1,NSP
c      print 601,J, (ILOSS(2,J,M),M = 1,30)
c      end do

c       PRINT *,'CHEMPL-PRODUCTION MATRIX'
c       Do J = 1, NSP
c       Print 601,J,(IPROD(J,M),M = 1,30)
c       end do
c  601 format(31I4)
c      stop
      DO 1 I=1,NZ
      XP(I) = 0.
   1  XL(I) = 0.
C
C   LOSS FREQUENCY XL
      NL = NUML(K)
      DO 2 L=1,NL
      J = ILOSS(1,K,L)
      M = ILOSS(2,K,L)
      DO 2 I=1,NZ
c-JL add dependencies checker(courtesy to Jim)
      IF(I>1) GO TO 2 
      IF(I<NZ) GO TO 2 
      IF(D(M,I)>1.0E-60)GO TO 2
      PRINT 99, K 
   99 format(/'k=',I3)  
      PRINT 100, J,M,D(M,I) 
  100 FORMAT('in finding XL,J=',I3,2x,'M=',I3,3x,'D(M,I)=',1pe10.3)
   2  XL(I) = XL(I) + AR(J,I)*D(M,I)
C
C   PRODUCTION RATE XP
      NP = NUMP(K)
      DO 3 L=1,NP
      J = IPROD(K,L)
      M = JCHEM(1,J)
      N = JCHEM(2,J)
      DO 3 I=1,NZ
      IF(I>1) GO TO 3
      IF(I<NZ) GO TO 3 
      IF(D(M,I)>1.0E-60.AND.D(N,I)>1.0E-60)GO TO 3
      print 99,K 
      PRINT 101,J,M,N,D(M,I),D(N,I)
  101 FORMAT('in finding XP,J=',I3,2x,'M=',I3,2x,'N=',I3,2x,'D(M,I)=',
     2  1pe10.3,2x,'D(N,I)=',E10.3) 
   3  XP(I) = XP(I) + AR(J,I)*D(M,I)*D(N,I)
      RETURN
      END
