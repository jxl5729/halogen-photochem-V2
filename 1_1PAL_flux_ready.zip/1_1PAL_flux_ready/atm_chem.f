        
         program atm_chem

c-JL on Feb 2022: add iodine chemistry to the code while update most of the
c     chemistry scheme. 
c
C     This program was created by James Kasting and modified mainly by
c     Alex Pavlov (AP) and Kara Kerelove (KK). The user-friendly version 
c     of this code was created by Antigona Segura (AS) (2005).
c     Some modifications are identified with the author's initials.
c
c     The code is mostly written in f77 but is compiled in f90 and it 
c     contains some f90 features.
c
C     This program was created from PRESO3.F in June, 1995, for the
C     purpose of calculating ozone levels on planets around stars of
C     different spectral types. It differs from PRESO3 by including 
C     NO3, N2O5, and CL2O2, and by not including the anthropogenic
C     CFC's. Sulfur chemistry was added by Alex Pavlov.
c     
c     The UV fluxes for stars that are not the Sun were provided by
c     Martin Cohen from new IUE (+model) data. 
c
c     Check the notes along the main program before use it. Look for 
c     the word 'NOTE:'
C
C     This program has been updated to the JPL '92 rate constant
C     recommendations. I have not checked all the photolysis cross
C     sections to see if they are up to date.
C
C         THIS PROGRAM IS DESIGNED SPECIFICALLY FOR AN O2 LEVEL
C     OF 1 PAL.  IT DIFFERS FROM THE OLD PRIMO3 BY INCLUDING AN
C     UPDATED ALGORITHM FOR CALCULATING PHOTOLYSIS OF O2 IN THE
C     SCHUMANN-RUNGE BANDS.  THE PHOTOLYSIS ALGORITHMS FOR O2 AND
C     NO MAY NOT BE APPLICABLE TO LOWER O2 LEVELS.  (THIS HAS NOT
C     BEEN CHECKED, BUT IT WOULD BE SURPRISING IF THEY WERE.)
C
C     THIS VERSION OF PRESO3 ALSO CONTAINS THE MODIFICATIONS USED IN 
C     PRIMO2 TO CALCULATE O2 SCHUMANN-RUNGE PHOTOLYSIS BY EXPONENTIAL
C     SUMS AND NO PHOTOLYSIS BY THE MODIFIED CIESLIK AND NICOLET METHOD.
C     THIS EDITION ALSO HAS GIORGI AND CHAMEIDES RAINOUT RATES AND A 
C     MANABE-WETHERALD RELATIVE HUMIDITY DISTRIBUTION. 
C
C       THIS PROGRAM IS A ONE-DIMENSIONAL MODEL OF THE PRIMORDIAL
C     ATMOSPHERE.  THE MIXING RATIOS OF THE LONG-LIVED SPECIES
C     ARE CALCULATED FROM THE EQUATION
C
C     DF/DT  =  (1/N)*D/DZ(KN*DF/DZ) + P/N - LF
C
C     WHERE
C     F = MIXING RATIO (USOL)
C     K = EDDY DIFFUSION COEFFICIENT (EDD)
C     N = TOTAL NUMBER DENSITY (DEN)
C     L = CHEMICAL LOSS FREQUENCY (XL)
C     P = CHEMICAL PRODUCTION RATE (XP)
C
C          THE SYSTEM OF PDES IS SOLVED USING THE REVERSE EULER
C     METHOD.  LETTING THE TIME STEP GO TO INFINITY GIVES YOU NEWTONS
C     METHOD, E.G. IT REVERTS TO AN EFFICIENT STEADY-STATE SOLVER.
C
C          THE LIST OF SUBROUTINES IS AS FOLLOWS:
C     (1) GRID   -  SETS UP THE ALTITUDE GRID
C     (2) RATES  -  DEFINES CHEMICAL REACTION RATES AND RAINOUT RATE
C     (3) PHOTO  -  COMPUTES PHOTOLYSIS RATES (CALLS TWOSTR)
C     (4) DENSTY -  COMPUTES ATMOSPHERIC DENSITIES FROM HYDROSTATIC
C                   EQUILIBRIUM AND INITIALIZES ABSORBER PROFILES
C     (5) DIFCO  -  COMPUTES DK = K*N BETWEEN GRID POINTS
C     (6) OUTPUTP -  PRINTS OUT RESULTS
C     (7) DOCHEM - DOES CHEMISTRY FOR ALL SPECIES AT ALL GRID
C                  POINTS BY CALLING CHEMPL
C     (8) CHEMPL - COMPUTES CHEMICAL PRODUCTION AND LOSS RATES
C                  FOR ONE SPECIES AT ALL GRID POINTS
C     (9) LTNING -  COMPUTES LIGHTNING PRODUCTION RATES FOR O2 AND
C                   N2 BASED ON CHAMEIDES' RESULTS
C    (10) SCALE  -  CAN BE USED TO SCALE THE EQUATIONS BY ARBITRARY
C                   FACTORS TO IMPROVE CONDITIONING OF MATRIX
C
C          OTHER DEFINED FUNCTIONS INCLUDE:
C     (1) TBDY   -  COMPUTES 3-BODY REACTION RATES
C     (2) E1     - EXPONENTIAL INTEGRAL OF ORDER ONE
c
C***********************************************************
C
C        THIS PROGRAM DOES THE CHEMISTRY AUTOMATICALLY.  THE CHEMICAL
C     REACTIONS ARE ENTERED ON DATA CARDS IN FIVE 10-DIGIT COLUMNS
C     STARTING IN COLUMN 11, I.E.
C
C         REAC1     REAC2     PROD1     PROD2     PROD3
C
C     THE IMPORTANT PARAMETERS DESCRIBING THE CHEMISTRY ARE
C        NR   = NUMBER OF REACTIONS
C        NSP  = NUMBER OF CHEMICAL SPECIES
C        NSP1 = NSP + 1 (INCLUDES HV)
C        NQ   = NUMBER OF SPECIES FOR WHICH A DIFFUSION EQUATION
C               IS SOLVED
C        NMAX = MAXIMUM NUMBER OF REACTIONS IN WHICH AN INDIVIDUAL
C               SPECIES PARTICIPATES
C
C        PHOTOLYSIS REACTIONS ARE IDENTIFIED BY THE SYMBOL HV (NOT
C     COUNTED IN EVALUATING NSP).  THREE-BODY REACTIONS ARE WRITTEN
C     IN TWO-BODY FORM, SO THE DENSITY FACTOR MUST BE INCLUDED IN
C     THE RATE CONSTANT.
C        THE CHEMICAL REACTION SCHEME IS STORED IN THE FOLLOWING MATRICE
C
C     ISPEC(NSP2) = VECTOR CONTAINING THE HOLLERITH NAMES OF THE
C                  CHEMICAL SPECIES.  THE LAST ENTRY MUST BE HV.
C     JCHEM(5,NR) = MATRIX OF CHEMICAL REACTIONS.  THE FIRST TWO ARE
C                   REACTANTS, THE LAST THREE ARE PRODUCTS.
C     ILOSS(2,NSP,NMAX) = MATRIX OF LOSS PROCESSES.  ILOSS(1,I,L)
C                         HOLDS REACTION NUMBER J, ILOSS(2,I,L) HOLDS
C                         REACTANT NUMBER.
C     IPROD(NSP,NMAX) = MATRIX OF PRODUCTION PROCESSES.  IPROD(I,L)
C                       HOLDS REACTION NUMBER J.
C     NUML(NSP) = NUMBER OF NON-ZERO ELEMENTS FOR EACH ROW OF ILOSS
C     NUMP(NSP) = NUMBER OF NON-ZERO ELEMENTS FOR EACH ROW OF IPROD
C
c      PARAMETER(NZ=64, NQ=34, NQT=NQ+1)
c      PARAMETER(NEQ=NQ*NZ,LDA=3*NQ+1)
c      PARAMETER(NR=220, NF=34)
c      PARAMETER(NSP=55, NSP1=NSP+1, NSP2=NSP+2, NMAX=70)

       INCLUDE 'INCLUDECHEM/parNZ.inc'
       INCLUDE 'INCLUDECHEM/parNQ_NQT.inc'
       INCLUDE 'INCLUDECHEM/parNEQ_LDA.inc'
       INCLUDE 'INCLUDECHEM/parNR.inc'
       INCLUDE 'INCLUDECHEM/parNF.inc'
       INCLUDE 'INCLUDECHEM/parNSP_NSP1_NSP2.inc'
       INCLUDE 'INCLUDECHEM/parNMAX.inc'
       INCLUDE 'INCLUDECHEM/parCORRK.inc'
       INCLUDE 'INCLUDECHEM/comCORRK.inc' !Correlated-k tables       

      DIMENSION FVAL(NQ,NZ),FV(NQ,NZ),DJAC(LDA,NEQ),RHS(NEQ),IPVT(NEQ)
     2  ,SGFLUX(NQ),SMFLUX(NQ),VDEP(NQ),USAVE(NQ,NZ),R(NZ),U(NQ)
      DIMENSION UOLD(67,100),TOLD(100),EDDOLD(100),DENOLD(100),
     2  SO4AEROLD(100),AERSOLOLD(100,3),WFALLOLD(100,3),RPAROLD(100,3)
      DIMENSION DPU(NZ,3),DPL(NZ,3)
      DIMENSION TA(NZ),TB(NZ),TC(NZ),TY(NZ)                                    
      DIMENSION TSAV(NZ),TDUM(NZ),TP1(NZ)
      DIMENSION water(NZ),FLOW(NQT),fluxsave(108),sfxsave(10)

c-JL:add IERR to better track chemical prod/loss matrix
c-JL add RCOND to track the condition number of the matrix 
      DIMENSION IERR(NR) 
      REAL:: RCOND 
      CHARACTER :: STARR*3,DIRDATA*4, AA*11,DIRIO*2
     
c Name of the star
      INCLUDE 'INCLUDECHEM/comSTR.inc'
      INCLUDE 'INCLUDECHEM/comFLUXPHOTO.inc'
c DIRP contains DIRCOUP, this variable is defined as a character 
c in comDIRP.inc
      INCLUDE 'INCLUDECHEM/comDIRP.inc'
      INCLUDE 'INCLUDECHEM/comABLOK.inc'
      INCLUDE 'INCLUDECHEM/comBBLOK.inc'
      INCLUDE 'INCLUDECHEM/comCBLOK.inc'
      INCLUDE 'INCLUDECHEM/comDBLOK.inc'
      INCLUDE 'INCLUDECHEM/comEBLOK1.inc'
      INCLUDE 'INCLUDECHEM/comFBLOK1.inc'
      INCLUDE 'INCLUDECHEM/comGBLOK.inc'
      INCLUDE 'INCLUDECHEM/comNBLOK.inc'
      INCLUDE 'INCLUDECHEM/comPRESS1.inc'
      INCLUDE 'INCLUDECHEM/comQBLOK.inc'
      INCLUDE 'INCLUDECHEM/comRBLOK.inc'
      INCLUDE 'INCLUDECHEM/comSBLOK.inc'
      INCLUDE 'INCLUDECHEM/comSULBLK.inc'
      INCLUDE 'INCLUDECHEM/comZBLOK.inc'
      INCLUDE 'INCLUDECHEM/comAERBLK.inc'
c
C-AJ/JL: change ALPHA(17,4) TO ALPHAOLD(17,4) in comQBLOK.inc
C ALPHA contains the weights for 12-pt Correlated k table
       data ALPHA/0.173927422568727, 0.326072577431273,
     & 0.326072577431273, 0.173927422568727/      
c-JL DON'T FORGET TO CHANGE NBLOK
        DATA LH2CO,LO,LH2O,LOH,LHO2,LH2O2,LO3,LH,LH2,LCH4,LCO,
     2  LCH3OOH,LCH3O2,LN2O,LNO,LNO2,LHNO2,LHNO3,LHO2NO2,LNO3,LN2O5,
     3  LCL2O2,LCH3CL,LHOCL,LCL,LCLO,LHCL,LCLONO2,LH2S,LHS,LSO,LSO2,
     4  LH2SO4,LHSO,LI,LI2,LIH,LIO,LIHO,LIO2,LINO,LICL,LI2O2,LI2O3,
     5  LI2O4,LINO2,LINO3,LCH3I,LCH2ICL,LCH2I2,LCO2,LCL2O,LCL2,LCLO2,
     6  LO2,LBRO,LBR,LBRO2,LIBR,LHBR,LHOBR,LBR2,LO21S,LO21D,LO1D,LBRNO3,
     7  LBRNO2,LBRCL,LCH2BR2,LCH3BR,LCH2BR,LCHBR2,LSO4AER,LCH21,LCH23,
     8  LCH3,LH3CO,LHCO,LN,LNOCL,LCLONO,LS, LSO21,LSO23,LHSO3,LSO3,
     9  LCH2I,LCH2CL,LS2,LN2/
     1  1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,
     2  24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,
     3  44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,
     4  64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,
     5  84,85,86,87,88,89,90/
C
C   NO PREDISSOCIATION COEFFICIENTS (ALLEN AND FREDERICK, 1982)
C
      DATA ANO/-1.790868E+1, -1.924701E-1, -7.217717E-2, 5.648282E-2,
     2  4.569175E-2, 8.353572E-3, 3*0.,
     3  -1.654245E+1, 5.836899E-1, 3.449436E-1, 1.700653E-1,
     4  -3.324717E-2, -4.952424E-2, 1.579306E-2, 1.835462E-2,
     5  3.368125E-3/
C
      DATA BNO/7.836832E+3, -1.549880E+3, 1.148342E+2, -3.777754E+0,
     2  4.655696E-2, 1.297581E+4, -2.582981E+3, 1.927709E+2,
     3  -6.393008E+0, 7.949835E-2/
C
      DATA LLNO/3*0, 2*2, 3*0, 2*1, 25*0/
      DATA RNO2/60*0., .79, .83, .66, .15, 4*0./
C
C   CONSTANTS FOR 1ST EXPONENTIAL INTEGRAL
      DATA AI/.99999193, -.24991055, .05519968, -.00976004,
     2  .00107857, -.57721566/
      DATA BI/8.5733287401, 18.0590169730, 8.6347608925,
     2  .2677737343/
      DATA CI/9.5733223454, 25.6329561486, 21.0996530827,
     2  3.9584969228/
      DATA NUML,NUMP/NSP*0,NSP*0/
C
C ***** SOLUBILITY (GIORGI AND CHAMEIDES) *****
      DATA H/1.3E+04, 1.0E-99, 1.0E-99, 1.0E+05, 3.3E+04,
     2       2.0E+05, 1.0E-99, 1.0E-99, 1.0E-99, 1.0E-99,
     3       1.0E-99, 2.0E+05, 3.3E+04, 1.0E-99, 1.9E-03,
     4       7.0E-03, 7.0E+11, 7.0E+11, 7.0E+11, 7.0E-03,
     5       7.0E+11, 1.0E-99, 1.0E-99, 1.0E-99, 1.0E-99,
     6       1.0E-99, 7.0E+11, 1.0E-99, 0.14, 1.E+5, 1.9E-3,
     7       1.E+4, 7E+11,9E+3,17*1.0E-99,4*1.0E-99,7*1.0E-99,
     8       3*1.0e-99,2*1.0E-99,5*1.0E-99/
C-AP  I have changed the Henry constant similar to the Archean code
C-AP  only for the sulfur species  from Archean. Note that Henry(SO2) 
C-AP  in the table is higher because we use effective Henry constant
C-AP  from Archean.

c  Temperature from the US Standard Atmosphere 1976. Used when the 
c  code is not coupled to the climate model.
C  JK   Data are estimated above 64 km. I'm adjusting the temperature
C       near the tropopause downward in order to get better 
C       statospheric H2O
      DATA T/288.15, 281.65, 275.15, 268.66, 262.17,
     &       255.68, 249.19, 242.70, 236.21, 229.73,
     &       223.25, 216.77, 216.65, 216.65, 216.65,
     &       216.65, 216.65, 216.65, 216.65, 216.65,
     &       216.65, 217.58, 218.57, 219.57, 220.56, 
     &       221.55, 222.54, 223.54, 224.53, 225.52,
     &       226.51, 227.50, 228.49, 230.97, 233.74, 
     &       236.51, 239.28, 242.05, 244.82, 247.58,
     &       250.35, 253.14, 255.88, 258.64, 261.40,
     &       264.16, 266.96, 269.68, 270.65, 270.65,
     &       270.65, 270.65, 269.03, 266.27, 263.52, 
     &       260.77, 258.02, 255.27, 252.52, 249.77, 
     &       247.02, 244.27, 241.53, 230.78, 230.50,
     &       230.50, 227.00, 225.10, 222.00, 219.60,
     &       216.00, 214.30, 212.00, 210.30, 208.00,
     &       206.40, 204.00, 202.50, 200.00, 198.60,
     &       196.00, 194.70, 192.00, 190.80, 189.00,
     &       186.90, 186.90, 186.90, 186.90, 186.90,
     &       188.00, 190.00, 191.00, 192.50, 194.00,
     &       195.00, 196.50, 198.00, 200.00, 202.00/
C
C JK Adjusting this downward in the lower troposphere to get Tsurf=288K
c      DATA T/285.15, 278.65, 272.15, 265.66, 261.17,
c     &       255.68, 249.19, 242.70, 236.21, 225.00,
c     &       210.00, 210.00, 210.00, 210.00, 210.00,
c     &       210.00, 214.00, 214.00, 216.65, 216.65,
c     &       216.65, 217.58, 218.57, 219.57, 220.56, 
c     &       221.55, 222.54, 223.54, 224.53, 225.52,
c     &       226.51, 227.50, 228.49, 230.97, 233.74, 
c     &       236.51, 239.28, 242.05, 244.82, 247.58,
c     &       250.35, 253.14, 255.88, 258.64, 261.40,
c     &       264.16, 266.96, 269.68, 270.65, 270.65,
c     &       270.65, 270.65, 269.03, 266.27, 263.52, 
c     &       260.77, 258.02, 255.27, 252.52, 249.77, 
c     &       247.02, 244.27, 241.53, 230.78, 230.50,
c     &       230.50, 227.00, 225.10, 222.00, 219.60,
c     &       216.00, 214.30, 212.00, 210.30, 208.00,
c     &       206.40, 204.00, 202.50, 200.00, 198.60,
c     &       196.00, 194.70, 192.00, 190.80, 189.00,
c     &       186.90, 186.90, 186.90, 186.90, 186.90,
c     &       188.00, 190.00, 191.00, 192.50, 194.00,
c     &       195.00, 196.50, 198.00, 200.00, 202.00/
c
C  Temperature profile for O2=0.1 PAL (from Segura et al.,2003, Fig.2)
c      DATA TP1/285.15, 278.65, 272.15, 265.66, 261.17,
c     &       255.68, 249.19, 242.70, 236.21, 225.00,
c     &       210.00, 210.00, 210.00, 210.00, 210.00,
c     &       210.00, 214.00, 214.00, 216.65, 216.65,
c     &       216.65, 217.58, 218.57, 219.57, 220.56, 
c     &       221.55, 222.54, 223.54, 224.53, 225.52,
c     &       226.51, 227.50, 228.49, 230.97, 233.74, 
c     &       236.51, 239.28, 237.00, 235.00, 233.00,
c     &       230.00, 227.00, 224.00, 222.00, 220.00,
c     &       218.00, 216.00, 214.00, 212.00, 210.00,
c     &       209.00, 208.00, 207.00, 206.00, 205.00, 
c     &       204.00, 203.00, 202.00, 201.00, 200.00, 
c     &       200.00, 200.00, 200.00, 200.00, 200.00,
c     &       200.00, 200.00, 200.00, 200.00, 200.00,
c     &       200.00, 200.00, 200.00, 200.00, 200.00,
c     &       200.00, 200.00, 200.00, 200.00, 198.60,
c     &       196.00, 194.70, 192.00, 190.80, 189.00,
c     &       186.90, 186.90, 186.90, 186.90, 186.90,
c     &       188.00, 190.00, 191.00, 192.50, 194.00,
c     &       195.00, 196.50, 198.00, 200.00, 202.00/


c-JL tempo
c      DATA EDD/64*0., 5.174E+05, 5.674E+05, 6.224E+05, 6.826E+05,
c     2  7.487E+05, 8.212E+05, 9.007E+05, 9.879E+05, 28*1.E6/
 
c NOTE: Boundary conditions are defined here
C ***** UPPER BOUNDARY FLUXES *****
      DATA SMFLUX/NQ*0./
C
C ***** EFFUSION VELOCITIES *****
      DATA VEFF/NQ*0./
C
C ***** UPPER BOUNDARY CONDITIONS ****
c  DATA MBOUND/0, 1, 8*0, 1, 24*0/
      DATA MBOUND/0, 1, 8*0, 1, 24*0,17*0,4*0,7*0,3*0,2*0,5*0/
C
C   0 = CONSTANT EFFUSION VELOCITY (VEFF)
C   1 = CONSTANT FLUX (SMFLUX)
C
C ***** LOWER BOUNDARY FLUXES *****
c NOTE: SGFLUX is redefined later in the main code when the O2 
c mixing ratio is less than 0.21 or when the star is not the Sun
      DATA SGFLUX/NQ*0./
C
C ***** DEPOSITION VELOCITIES (CM/s,NQ)****
c
c
c              H2CO O   H2O OH  HO2  H2O2 O3   H      CH3OOH CH3O2 
      DATA VDEP/0.2, 1., 0., 1., 1., 0.2,3.E-2,1., 3*0., 0.2, 1.,
C      N2O NO+NO2      CH3CL HOCL  CL          H2S   HS    SO 
     2  0., 2*0.2, 6*0.5, 0., 0.5, 1., 3*0.5, 0.02, 1., 3.E-4,
C            I   I2  IH  IO  IHO  IO2    ICL I2O2           INO3
     3  3*1.,1., 1., 1.,1.0, 1.0,0.2,0.2, 0.,  1.,1.,1.,0.75,0.75,
C      CH3I   CH2ICL     CH2I2  CO2  CL2O   CL2   CLO2   O2   BRO
     4 1.5E-5,7.1E-4, 1.0E-4, 0.1,  1.E-3, 1.E-3,1.E-3, 0., 3.0E-1,
C        BR   BRO2   IBR     HBR   HOBR    BR2  O21S  O21D  O1D BRNO3
     5 5.0E-1,5.0E-1,1.0E-1,5.0E-1,2.0E-1,5.0E-1,1.0, 1.0, 1.0, 1.0,
C       BRNO2   BRCL  CH2BR2 CH3BR  CH2BR  CHBR2
     6 1.0E-1, 1.0E-1,1.0E-1,1.0E-1,1.0E-1,1.0E-1/


c              H2CO O   H2O OH  HO2  H2O2 O3  H        CH3OOH CH3O2 
c      DATA VDEP/0.2, 1., 0., 1., 1., 0.2, 0.1, 1., 3*0., 0.2, 1.,
C      N2O NO+NO2      CH3CL HOCL  CL          H2S   HS    SO 
c     2  0., 2*0.2, 6*0.5, 0., 0.5, 1., 3*0.5, 0.02, 1., 3.E-4, 
c     3  3*1./
c Deposition velocities used for planets around quiescent M dwarfs
c      DATA VDEP/0.2, 1., 0., 1., 1., 0.2, 0.1, 1.,2.4e-4,0.,1.2e-4, 0.2,
c     2  1.,0., 2*0.2, 6*0.5, 0., 0.5, 1., 3*0.5, 0.02, 1, 3.E-4, 
c     3  3*1./
C
C ***** LOWER BOUNDARY CONDITIONS (NQT)*****
c NOTE: Mixing ratios for present Earth for H2,CO,CH4, N2O and CH3Cl
c are defined after the model parameters.
c fixed mixing ratios
C      DATA LBOUND/2*0, 1, 5*0, 1, 1, 1, 2*0, 1, 5*0, 3*0, 1, 12*0/
c fixed fluxes
c                      H2O     H2 CH4 CO     N2O         CH3CL
C       DATA LBOUND/2*0, 1, 5*0, 2, 2, 2, 2*0, 2, 5*0, 3*0, 2, 11*0,
C      I I2 IH IO IHO IO2  ICL    INO2   CH3I CH2I2 Cl2O CL2 CLO2 SO4AER
C     2 0, 2, 0, 1, 2, 0, 0, 0, 3*0, 0, 0, 2, 2, 2, 0, 0, 0,  0,    0/

c                      H2O     H2 CH4 CO     N2O         CH3CL
       DATA LBOUND/2*0, 1, 5*0, 2, 2, 2, 2*0, 2, 5*0, 3*0, 2, 11*0,
C     I I2 IH IO IHO IO2 INO ICL   INO2   CH3I     CO2   CL2 CLO2 O2
     2 0,2,0, 2, 1, 0,  0,   2, 3*0, 0, 0, 2, 2, 2, 1, 0, 0,  0, 1,
c     BRO BR BRO2 IBR HBR HOBR BR2 O21S O21D O1D BRNO3 BRNO2 BRCL CH2BR2
     3 1, 0, 0,   2,  0,  0,   2,  0,  0,    0,  0,    0,   0,    1,
C     CH3BR CH2BR CHBR2  SO4AER
     4 1,   0,   0,      0/

C   1 = CONSTANT MIXING RATIO
C   2 = CONSTANT UPWARD FLUX (SGFLUX)
C
C Modify Henry constants for sensitivity run comparison to Archean atmosphere
c      H(LHO2) = 9.E3
c      H(LH2O2) = 6.2E5
c      H(LH2CO) =  4.25E4
c-JL OVERRIDE HENRY'S LAW(MOL/L/BAR = M/ATM) 
       H(LI) = 0.08 !henrys-law.org
       H(LI2) = 3.24!henrys-law.org
       H(LIH) = 1.E99!henrys-law.org 
       H(LIO) = 4.5E2 !Saiz-Lopez et al.2014
       H(LIHO) = 1.53E4 !Sherwen et al. 2016
       H(LIO2) = 1.0E4 !Saiz-Lopez et al.2014 
       H(LINO) = 0.1
       H(LICL) = 111.5 !Sander et al. 2014 
       H(LI2O2) = 1.0E99 !assumed
       H(LI2O3) = 1.0E99 !assumed
       H(LI2O4) = 1.0E99 !assumed
       H(LINO2) = 0.3 ! Sherwen et al. 2016 
       H(LINO3) = 1.0E99!assumed  
       H(LCH3I) = 0.15 !JPL 
       H(LCH2ICL) = 0.1 
       H(LCH2I2) = 2.31 !JPL 
       H(LCL2O) = 17.!JPL 
       H(LCL2) = 9.29E-2!JPL 
       H(LCLO2) = 1.01 !JPL
       H(LBR2) = 0.725 !JPL
       H(LHOBR) = 1.E99 !JPL
       H(LHBR) = 7.1E13 !SHERWEN ET AL.2016
       H(LIBR) = 24.3 ! SHERWEN ET AL. 2016
C============== FILE SECTION =============================

      DIRDATA = 'DATA'
      DIRIO = 'IO'

c **** INPUT FILES
c
C-AJ/JL: read correlated k table; The data will be read in srbands.f under CHEM
      OPEN(UNIT=10, file =  DIRDATA//'/k4_0927.dat', status='old')
c This file contains the chemical reactions used in the code
      OPEN(unit=61, file= DIRDATA//'/primo3s.chm', status='old')
c-as Next file contains solar flux and atmospheric data
c-as it MUST be read for all the cases  
      OPEN(unit=62, file= DIRDATA//'/photos.pdat', status='old') 
      OPEN(unit=63,file= DIRDATA//'/h2so4.pdat',status='old')
      OPEN(unit=64,file= DIRDATA//'/eddy.pdat',status='old')

c Files with the input parameters
c NOTE: Check this two before runnig the program
       OPEN(unit=65,file= DIRIO//'/input_atmchem.dat')
       OPEN(unit=66,file= DIRIO//'/planet.dat')  

c-as Next file was formerly named atm_chem_coefs.dat.
c-as I has the same format as atm_composition.out   
      OPEN(unit=67, file= DIRIO//'/atm_composition.dat') 

c Next file is generated by the climate model contains altitude,
c temperature and water. Formerly called photo_input.dat.
c Only used when ICOUPLE=1
      OPEN(unit=71,file= DIRIO//'/fromClima2Photo.dat') 
      
c-as  Unit 72 is an input and output file that is shared with the climate code
c-as  when ICOUPLE= 1. It is OPEN later in the program to WRITE on it.
c Only used when ICOUPLE=1    
      OPEN(unit=72,file= DIRIO//'/mixing_ratios.dat')

      OPEN(unit=73, file= DIRDATA//'/faruvs.pdat')
      
c  NOTE: IMPORTANT files to read the far UV of all the stars (including 
c  the Sun) and the UV fluxes for stars others than the Sun.
c        74     fluxesKGF_photo.pdat
c        75     M star flux (name it as you like)
c        76     far UV flux (name depends on the star)

C **** OUTPUT FILES
c Main output
      OPEN(unit=90,file= DIRIO//'/outchem.dat')
c Files commented would contain information that is not
c needed for now but the write commands for them still in 
c program. To activate them just remove all c here and in 
c the write commands
c      OPEN(unit=10,file='primo3.plt')
c      OPEN(unit=14,file='primotemp.dat')
c      OPEN(unit=15,file='o3graph.dat')  

c-as MAIN output file MOVED to couple.f
C       OPEN(unit=90,file='outchem.dat')  

c Written on subroutine TWOSTR
c      OPEN(unit=82,file= DIRIO//'/wave_means.dat')

c This file contains the altitude in cm vs the ozone number density (cm^-3)
c      OPEN(unit=83,file= DIRIO//'/O3numdens.out')

c  This is an output file containing altitude, H2O, O3.
c  To be used as input of the climate model, formerly called Pass2SurfMP.dat
      OPEN(unit=84,file= DIRIO//'/fromPhoto2Clima.dat')

c This file contains total hydrogen mixing ratio vs. altitude (cm)
C These OUTPUT files are opened along the program 
      OPEN(unit=86,file= DIRIO//'/total_hydrogen.out')
      OPEN(unit=87,file= DIRIO//'/diffusion_coefs.out')

c In may 9 2019, Jl add the reaction rate table to the code to make life easier 
      OPEN(UNIT=15,file='IO/int.rates.out.dat')


C These OUTPUT files are opened along the program 
c	UNIT   	NAME  
c        19     mixing_ratios.dat (main program)

c=================================================================

********* SET MODEL PARAMETERS *****

C     ZY = SOLAR ZENITH ANGLE (IN DEGREES)
C     AGL = DIURNAL AVERAGING FACTOR FOR PHOTORATES
C     ISEASON = TELLS WHETHER P AND T VARY WITH TIME (THEY DON'T FOR
C               ISEASON < 3)
C     IZYO2 = TELLS WHETHER SOLAR ZENITH ANGLE VARIES WITH TIME (0 SAYS
C             IT DOESN'T; 1 SAYS IT DOES)
C     IO2 = 0 FOR ALLEN AND FREDERICK O2 SCHUMANN-RUNGE COEFFICIENTS
C         = 1 FOR EXPONENTIAL SUM FITS (FOR LOW-O2 ATMOSPHERES)
C     INO = 0 FOR ALLEN AND FREDERICK NO PREDISSOCIATION COEFFICIENTS
C         = 1 FOR MODIFIED CIESLIK AND NICOLET FORMULATION
C     EPSJ = AMOUNT BY WHICH TO PERTURB THINGS FOR JACOBIAN CALCULATION
C     ZTROP = TROPOPAUSE HEIGHT (ABOVE WHICH H2O BEHAVES AS A NONCONDENS
C             ABLE GAS
C     STARR - Character variable to choose a star, it can be:
c             Sun, F2V, K2V,dMV 
c             DO NOT FORGET quotation marks
c     ICOUPLE - 1 = Coupled to the climate model              
c               0 = Not coupled
C     FCO2 = CO2 mixing ratio when ICOUPLE = 0
C     FO2 = O2 mixing ratio when ICOUPLE = 0
C     DT = INITIAL TIME STEP
C     TSTOP = TIME AT WHICH CALCULATION IS TO STOP
C     NSTEPS = NUMBER OF TIME STEPS TO RUN (IF TSTOP IS NOT REACHED
      read(65,555)
      read(65,*)AA,STARR
      read(65,*)AA,FLUXFAC
      read(65,*)AA,INIT
      read(65,*)AA,TSTOP
      read(65,*)AA,DT
      read(65,*)AA,NSTEPS
      read(65,*)AA,ZY
      read(65,*)AA,AGL
      read(65,*)AA,ISEASON
      read(65,*)AA,IZYO2
      read(65,*)AA,IO2
      read(65,*)AA,INO
      read(65,*)AA,EPSJ
      read(65,*)AA,ZTROP
      read(65,*)AA,FCO2
      read(65,*)AA,FO2
  555  format(3/)
      close(65)
      ICOUPLE = 0

*** Read the flux from a star
      CALL readstar(FLUXFAC)

***** READ THE PLANET PARAMETER DATAFILE *****
      READ(66,502) G,FSCALE,ALB,DELZ,ZTROP !JL: removes JTROP
 502  FORMAT(F5.1/,F4.2/,F5.3/,E5.1/,E5.1)
      close(66)
C
***** READ THE ATMOSPHERIC COMPOSITION
c      READ(67,400) UOLD,TOLD,EDDOLD,DENOLD,SO4AEROLD,AERSOLOLD,
c     2  WFALLOLD,RPAROLD
c 400  FORMAT(1P8E12.5)
c      close(67)
       READ(67,400) USOL,TDUM,EDD,DEN,SO4AER,AERSOL,WFALL,RPAR
  400  FORMAT(1P8E12.5)
       close(67)
c
c      DO I=1,67
c      DO J=1,100
c      USOL(I,J) = UOLD(I,J)
c      EDD(J) = EDDOLD(J)
c      DEN(J) = DENOLD(J)
c      SO4AER(J) = SO4AEROLD(J)
c      AERSOL(J,1) = AERSOLOLD(J,1)
c      WFALL(J,1) = WFALLOLD(J,1)
c      RPAR(J,1) = RPAROLD(J,1)
c      AERSOL(J,2) = AERSOLOLD(J,2)
c      WFALL(J,2) = WFALLOLD(J,2)
c      RPAR(J,2) = RPAROLD(J,2)
c      AERSOL(J,3) = AERSOLOLD(J,3)
c      WFALL(J,3) = WFALLOLD(J,3)
c      RPAR(J,3) = RPAROLD(J,3)
c      end do 
c      end do
c      DO J = 1,NZ
c      USOL(2,J) = USOL(2,J)*4.!O
c      USOL(4,J) = USOL(4,J)*5.!OH
c      USOL(6,J) = USOL(6,J)/3.!H2O2
c      USOL(5,J) = USOL(5,J)/3.!HO2
c      USOL(9,J) = 5.5E-7!H2
c      USOL(10,J) = 1.6E-6!CH4
c      USOL(8,J) = USOL(8,J)/8.!H
c      USOL(11,J) = 9.0E-8 !CO
c      USOL(12,J) = USOL(12,J)*20.!CH3OOH
c      USOL(13,J) = USOL(13,J)*10.!CH3O2
c      USOL(14,J) = 3.0E-7!N2O
c      USOL(20,J) = USOL(20,J)*8.!NO3
c      USOL(23,J) = 5.0E-10!CH3CL
C      USOL(7,J) = USOL(7,J)*100.!O3
c      USOL(35,J) = 1.0E-14 !USOL(35,J)/2. !I
c      USOL(36,J) = 1.0E-13 !I2 has data
c      USOL(37,J) = USOL(37,J)/2. !1.0E-14 ! IH
c      USOL(38,J) = 2.5E-13 !USOL(38,J)/3. !IO has data
c      USOL(39,J) = 1.0E-13 !IHO has data
c      USOL(40,J) = USOL(40,J)/2. !1.E-14! IO2
c      USOL(41,J) = USOL(41,J)/2. !1.0E-14 !INO
c      USOL(42,J) = 1.0E-14 !ICL
c      USOL(43,J) = USOL(43,J)/2.!1.E-13 !I2O2
c      USOL(44,J) = USOL(44,J)/2. !1.E-13 !I2O3
c      USOL(45,J) = USOL(45,J)/2.!1.0E-13 !I2O4
c      USOL(46,J) = USOL(46,J)/2.! 1.0E-13!!INO2
c      USOL(47,J) = USOL(47,J)/2.!1.0E-13 !INO3
c      USOL(48,J) = 1.0E-15!1.1E-13 !CH3I has data
c      USOL(49,J) = 1.0E-16!1.1E-13 !CH2ICL has data
c      USOL(50,J) = 1.0E-16!1.1E-13 !CH2I2  has data   
c      END DO 
c
c      DO J = 1,NZ
c      USOL(51,J) = 3.0E-4 !CO2
c      USOL(56,J) = 2.0E-13 ! BRO
c      USOL(57,J) = 1.0E-13 ! BR
c      USOL(58,J) = 1.0E-12 ! BRO2 
c      USOL(59,J) = 1.E-14 ! IBR
c      USOL(60,J) = 1.0E-13 ! HBR 
c      USOL(61,J) = 1.0E-12 ! HOBR 
c      USOL(62,J) = 1.0E-13 ! BR2
c      USOL(63,J) = 1.0E-14 !O21S
c      USOL(64,J) = 1.0E-12 !O21D
c      USOL(65,J) = 1.0E-18 !O1D
c      USOL(66,J) = 1.0E-13 !BrNO3
c      USOL(67,J) = 1.0E-13 !BrNO2
c      USOL(68,J) = 1.0E-13!BRCL
c      USOL(69,J) = 1.0E-12!CH2BR2
c      USOL(70,J) = 8.0E-12!CH3BR
c      USOL(71,J) = 1.0E-13!CH2BR
c      USOL(72,J) = 1.0E-13!CHBR2
c      END DO
C JK i/24/16 Change the temperature profile for low-O2 atmospheres
C     DO J=1,NZ
C Use this for O2=0.1 PAL
C     T(J) = TP1(J)
C Use this for O2<0.1 PAL
C      IF(J.GE.16) T(J) = amin1(T(J),200.)
C     ENDDO
c      Print 5000
c 5000 Format(/1x,'T =')
c      Print 5001, T
c 5001 format(1p10e10.3)

      if (ICOUPLE.eq.1) then
	DO J=1, NZ
c Read the temperature and water profiles from the climate code
	  READ(71,*) Z(J),T(J),water(J)
	END DO
      close(71)
      endif
 351  FORMAT(I3,1PE10.3, 1PE12.3, 1PE12.3)

C-KK  Surface mixing ratios to share with the climate code
c  FAR is not needed on this code but it must be transfered to 
c  the climate model.
        READ(72,*) FAR                  !Argon
	READ(72,*) FCH4			!Methane
	READ(72,*) JTROP		!Tropopause layer
        READ(72,*) O3OLD                !Former O3 column depth
   

C   Initial constant mixing ratios used for present Earth
c       if (STARR=="Sun".and.FO2.gt.0.20) then
c           READ(67,400) USOL,T,EDD,DEN,SO4AER,AERSOL,WFALL,RPAR

       if(INIT.eq.1) goto 77
c      Surface mixing ratios
         if(LBOUND(9).eq.1)FH2 = 5.5E-7
         if(LBOUND(11).eq.1)FCO = 9.0E-8
         if(LBOUND(14).eq.1)FN2O = 3.0E-7
         if(LBOUND(23).eq.1)FCH3CL = 5.0E-10

       DO i = 1, NZ
        if(LBOUND(9).eq.1) then
           USOL(LH2, i) = USOL(LH2,i)*(FH2/USOL(LH2,1))
        endif
       if(LBOUND(10).eq.1) then
           USOL(LCH4,i) = USOL(LCH4,i)*(FCH4/USOL(LCH4,1))
        endif
        if(LBOUND(11).eq.1)then
            USOL(LCO,i) = USOL(LCO,i)*(FCO/USOL(LCO,1))
        endif
        if(LBOUND(14).eq.1) then
            USOL(LN2O,i) = USOL(LN2O,i)*(FN2O/USOL(LN2O,1))
        endif
        if(LBOUND(23).eq.1)then
            USOL(LCH3CL,i) = USOL(LCH3CL,i)*(FCH3CL/USOL(LCH3CL,1))
        endif
        END DO
   77   continue       
c        endif
       
C-KK	Constant flux for long-lived gases. For details see the model 
c       description on: Segura et al. (2003) Astrobiology, 3(4), 689-708.
C-KK	Only used at O2 levels lower than 1 PAL and for planets around 
C-KK    other stars
C-KK	9 - H2   10 - CH4   11 - CO  14 - N2O   23 - CH3Cl
         if(LBOUND(9).eq.2)SGFLUX(9) = -5.72E9 !-8.61E9 !H2
c         if(LBOUND(10).eq.2)SGFLUX(10) = 2.02E11
        if(LBOUND(10).eq.2)SGFLUX(10) = 1.44E11  !value for AD Leo
         if(LBOUND(11).eq.2)SGFLUX(11) = 4.00E10 !3.46E11 !CO
         if(LBOUND(14).eq.2)SGFLUX(14) = 1.26E9 !1.12E9 N2O
         if(LBOUND(23).eq.2)SGFLUX(23) = 8.64E5 !3.99E8 CH3CL
C-JL IODINE FLUX 
         IF(LBOUND(36).EQ.2)SGFLUX(36) = 4.53E8 !3.83E6 !I2
         IF(LBOUND(38).EQ.2)SGFLUX(38) = 1.01E10 !3.83E6 !IO
         IF(LBOUND(39).EQ.2)SGFLUX(39) = -8.47E9  !IHO
         IF(LBOUND(48).EQ.2)SGFLUX(48) = 3.73E4 !7.66E6 !CH3I
         IF(LBOUND(49).EQ.2)SGFLUX(49) = 1.39e4 !5.01E6 !CH2ICL
         IF(LBOUND(50).EQ.2)SGFLUX(50) = 2.33E5!3.24E6 !CH2I2 
         IF(LBOUND(42).EQ.2)SGFLUX(42) = 7.94E7 !ICL
         IF(LBOUND(59).EQ.2)SGFLUX(59) = 1.00E8 !IBR
         IF(LBOUND(62).EQ.2)SGFLUX(62) = 1.60E9 !BR2          
         IF(LBOUND(69).EQ.2)SGFLUX(69) = 1.01E5 !CH2BR2         

       write(90,*)"SOLAR ZENITH ANGLE (deg) = ", ZY
       write(90,*)"FIXED SPECIES MIXING RATIOS:"
       write(90,*)"   O2 = ",FO2," CO2 = ",FCO2," CH4 = ",FCH4
C	 print*,"   H2 = ",FH2," CO = ",FCO," N2O = ",FN2O

C ***** SPECIES DEFINITIONS *****
      ISPEC(1) = 4HH2CO
      ISPEC(2) = 1HO
      ISPEC(3) = 3HH2O
      ISPEC(4) = 2HOH
      ISPEC(5) = 3HHO2
      ISPEC(6) = 4HH2O2
      ISPEC(7) = 2HO3
      ISPEC(8) = 1HH
      ISPEC(9) = 2HH2
      ISPEC(10) = 3HCH4
      ISPEC(11) = 2HCO
      ISPEC(12) = 6HCH3OOH
      ISPEC(13) = 5HCH3O2
      ISPEC(14) = 3HN2O
      ISPEC(15) = 2HNO
      ISPEC(16) = 3HNO2
      ISPEC(17) = 4HHNO2
      ISPEC(18) = 4HHNO3
      ISPEC(19) = 6HHO2NO2
      ISPEC(20) = 3HNO3
      ISPEC(21) = 4HN2O5
      ISPEC(22) = 5HCL2O2
      ISPEC(23) = 5HCH3CL
      ISPEC(24) = 4HHOCL
      ISPEC(25) = 2HCL
      ISPEC(26) = 3HCLO
      ISPEC(27) = 3HHCL
      ISPEC(28) = 6HCLONO2
      ISPEC(29) = 3HH2S
      ISPEC(30) = 2HHS
      ISPEC(31) = 2HSO
      ISPEC(32) = 3HSO2
      ISPEC(33) = 5HH2SO4
      ISPEC(34) = 3HHSO
C-JL ADD IODINE AND ADDITIONAL CL
      ISPEC(35) = 1HI
      ISPEC(36) = 2HI2
      ISPEC(37) = 2HIH
      ISPEC(38) = 2HIO
      ISPEC(39) = 3HIHO
      ISPEC(40) = 3HIO2
      ISPEC(41) = 3HINO
      ISPEC(42) = 3HICL
      ISPEC(43) = 4HI2O2
      ISPEC(44) = 4HI2O3
      ISPEC(45) = 4HI2O4
      ISPEC(46) = 4HINO2
      ISPEC(47) = 4HINO3
      ISPEC(48) = 4HCH3I
      ISPEC(49) = 6HCH2ICL
      ISPEC(50) = 5HCH2I2
      ISPEC(51) = 3HCO2  !4HCH2I
      ISPEC(52) = 4HCL2O
      ISPEC(53) = 3HCL2
      ISPEC(54) = 4HCLO2
      ISPEC(55) = 2HO2
      ISPEC(56) = 3HBRO
      ISPEC(57) = 2HBR
      ISPEC(58) = 4HBRO2
      ISPEC(59) = 3HIBR
      ISPEC(60) = 3HHBR
      ISPEC(61) = 4HHOBR
      ISPEC(62) = 3HBR2
      ISPEC(63) = 4HO21S
      ISPEC(64) = 4HO21D
      ISPEC(65) = 3HO1D
      ISPEC(66) = 5HBRNO3
      ISPEC(67) = 5HBRNO2
      ISPEC(68) = 4HBRCL
      ISPEC(69) = 6HCH2BR2
      ISPEC(70) = 5HCH3BR
      ISPEC(71) = 5HCH2BR
      ISPEC(72) = 5HCHBR2 
C   TRIDIAGONAL SOLVER
      ISPEC(73) = 6HSO4AER
C   Short-lived species
      ISPEC(74) = 4HCH21
      ISPEC(75) = 4HCH23
      ISPEC(76) = 3HCH3
      ISPEC(77) = 4HH3CO
      ISPEC(78) = 3HHCO
      ISPEC(79) = 1HN
      ISPEC(80) = 4HNOCL
      ISPEC(81) = 5HCLONO
      ISPEC(82) = 1HS
      ISPEC(83) = 4HSO21
      ISPEC(84) = 4HSO23
      ISPEC(85) = 4HHSO3
      ISPEC(86) = 3HSO3
      ISPEC(87) = 4HCH2I
      ISPEC(88) = 5HCH2CL
C   Inert species
      ISPEC(89) = 2HS2
      ISPEC(90) = 2HN2
      ISPEC(91) = 2HHV
      ISPEC(92) = 1HM

      do i=1,NSP
       NUML(i) = 0
       NUMP(i) = 0
      enddo

C
c      print *,'VDEP(LIHO)= ',VDEP(LIHO)
C ***** READ THE CHEMISTRY DATA CARDS *****
      READ (61,200) JCHEM
 200  FORMAT(10X,A8,2X,A8,2X,A8,2X,A8,2X,A8)
      close(61)
     
C NOTE: This command will print the list of chemical reactions in the 
c       output file 
c      PRINT 201,(J,(JCHEM(M,J),M=1,5),J=1,NR)
c 201  FORMAT(1X,I3,1H),5X,A8,4H +  ,A8,7H  =    ,A8,4H +  ,A8,4X,A8)
      KJAC = LDA*NEQ
c      PRINT 202,NQ,NZ,KJAC
c 202  FORMAT(//1X,'NQ=',I2,5X,'NZ=',I3,5X,'KJAC=',I7)
C     
c     
C ***** REPLACE HOLLERITH LABELS WITH SPECIES NUMBERS IN JCHEM *****
      DO 5 J=1,NR
      DO 5 M=1,5
      IF(JCHEM(M,J).EQ.' ' ) GO TO 5
C-AP Change NSP1 to NSP2 because we added M to the species list
      DO 6 I=1,NSP2
      IF(JCHEM(M,J).NE.ISPEC(I)) GO TO 6
      JCHEM(M,J) = I
      GO TO 5
   6  CONTINUE
      IERR = J
      GO TO 25
   5  CONTINUE
C
c      PRINT 501,(J,(JCHEM(M,J),M=1,5),J=1,NR)
c  501  FORMAT(1X,I3,5X,5I4)
c       KJAC = LDA*NEQ 
C ***** FILL UP CHEMICAL PRODUCTION AND LOSS MATRICES *****
      DO 7 M=1,2
      N = 3-M
      DO 7 J=1,NR
      I = JCHEM(M,J)
      IF(I.LT.1.OR.I.GT.NSP) GO TO 7
      NUML(I) = NUML(I) + 1
      IF(NUML(I).GT.NMAX) GO TO 20
      K = NUML(I)
      ILOSS(1,I,K) = J
      ILOSS(2,I,K) = JCHEM(N,J)
   7  CONTINUE
C
c      print *, 'CHEMICAL LOSS MATRIX'
c      DO J = 1,NSP
c      print 601,J, (ILOSS(1,J,K),K = 31,60)
c      end do 
c      DO J = 1,NSP
c      print 601,J, (ILOSS(2,J,K),K = 31,60)
c      end do
c      print *, 'CHEMICAL LOSS MATRIX'
c      DO J = 1,NSP
c      print 601,J, (ILOSS(1,J,K),K = 1,30)
c      end do
c      DO J = 1,NSP
c      print 601,J, (ILOSS(1,J,K),K = 1,30)
c      end do
c
      DO 8 M=3,5
      DO 8 J=1,NR
      I = JCHEM(M,J)
      IF(I.LT.1.OR.I.GT.NSP) GO TO 8
      NUMP(I) = NUMP(I) + 1
      IF(NUMP(I).GT.NMAX) GO TO 20
      K = NUMP(I)
      IPROD(I,K) = J
   8  CONTINUE
c      PRINT *,'PRODUCTION MATRIX'
c c      Do J = 1, NSP 
c c      Print 601,J,(IPROD(J,K),K = 31,60) 
c c      end do 
c c 601 format(31I4)
      
c       print *, 'I3 = ', I
c       print *, 'J3= ',J
c       print *, 'K= ',K
c       print *, 'NR2= ',NR
c       print *, 'NUMP(1)= ',NUMP(1)
c       print *, 'NUMP(30)= ',NUMP(30)
c       print *, 'ILOSS= ', ILOSS
c       print *, 'IPROD= ', IPROD

c       DO  I=1,NSP
c       print *, ILOSS
c       end do  
C-AP
C
** Read the eddy diffusion profile
	do J=1,NZ
	 READ(64,245) EDD(J),Z(J)
	end do 
 245  FORMAT(2(1PE11.3, 1X))
      close(64)

      LTIMES = 0       !Counter for the photorate subroutine
      ISULF = 0
      VOLFLX = 3.E9    !Volcanic flux
c      print *,'hello world'
      CALL GRID
      DZ = Z(2) - Z(1)
c      print *, 'DZ =', DZ,'Dz2= ',Z(2),'DZ1= ',Z(1)
      CALL DENSTY(FO2,FCO2,P0) 
      CALL RATES
      CALL DIFCO(FO2,FCO2)
c      print *,'AR at the surface'
c      print 1500,(AR(J,1), J = 1,NR)
c 1500 format(1p10e9.2)
c      print *,'AR(30)= ',AR(30,I) 
c      print *,'USOL(1,70)= ',USOL(1,70)
c  If the star is other than the Sun or there is a flare
c  the fluxes are saved here
      do i=1,108
       fluxsave(i)=FLUX(i)
      enddo 
     
c  Read the data for the photochemistry and the UV flux of the Sun
      CALL READPHOTO
      if(STARR.ne.'Sun') then
        do i=1,108
         FLUX(i)= fluxsave(i)
        enddo       
      endif
c      
C AJ/JL: read correlated k table from srbands.f
      CALL SRBANDS(T)
c
c
c      
** Water calculation

      JTROP = ZTROP/DZ + 0.01

      CALL PSATRAT(H2O)
       DO 23 J=1,JTROP 
  23    USOL(LH2O,J) = H2O(J)
      
       if(ICOUPLE.eq.1) then
C-KK	This is added to make sure that tropospheric water is being
C-KK	handled consistently. The #s are imported from the climate model.
        DO J = 1, NZ
         USOL(LH2O,J) = water(J)
        END DO
       endif       !end of water calculation

      CALL LTNING(FO2,FCO2,P0)
      CALL AERTAB
      NZ1 = NZ - 1
      HA = 1.38E-16*T(NZ)/(1.67E-24*28.*980.)

      DTINV = 1./DT
      TIME = 0.
c      print *,'USOL(1,70)= ',USOL(1,70)
C
C ***** PRINT OUT INITIAL DATA *****
      CALL OUTPUTP(0,NSTEPS,0.,FLOW)
c      print *,'USOL(1,100)= ',USOL(1,100)
C     
C ***** SET JACOBIAN DIMENSIONING PARAMETERS *****
      KD = 2*NQ + 1
      KU = KD - NQ
      KL = KD + NQ
C
C   PRINT OUT RESULTS EVERY NPR TIME STEPS
      NPR = NSTEPS
      PRN = NPR
C
C   DO PHOTORATES EVERY MP TIME STEPS
      NPHOT = 0
      MP = 3
      PM = MP
      NN = 0
C
C ***** START THE TIME-STEPPING LOOP *****
C	STARSHIP
      DO 1 N=1,NSTEPS
      TIME = TIME + DT
      NN = NN + 1
      MS = (N-1)/MP
      SM = (N-1)/PM
      IF(NN.EQ.NSTEPS) SM = MS
      IF(SM-MS.GT.0.01) GO TO 18
      IF(N.GT.1 .AND. TIME.LT.1.E4) GO TO 18
C
C   STORE ABSORBERS USED TO BLOCK OUT SOLAR UV RADIATION
      DO 35 I=1,NZ
      H2O(I) = ABS(USOL(LH2O,I))
      O3(I) = ABS(USOL(LO3,I))
      O2(I) = FO2
      CO2(I) = FCO2
      FSO2(I) = ABS(USOL(LSO2,I))
      H2S(I) = ABS(USOL(LH2S,I))
      CH4(I) = ABS(USOL(LCH4,I))      
  35  CONTINUE
       
      IDO = 0
      IF (NN.EQ.NSTEPS) IDO = 1      
      CALL PHOTO(ZY,AGL,LTIMES,ISEASON,IZYO2,IO2,INO,IDO) !replace IDO=1
C ***** FILL UP RATE MATRIX *****
      DO 56 I=1,NZ
      AR(23,I) = PO2D(I)
      AR(24,I) = PO2(I)
      AR(25,I) = PH2O(I)
      AR(26,I) = PO3D(I)
      AR(27,I) = PO3(I)
      AR(28,I) = PH2O2(I)
      AR(29,I) = PCO2(I)
      AR(38,I) = PH2(I)
      AR(39,I) = PHCO(I)
      AR(42,I) = PCO2D(I)
      AR(50,I) = PHO2(I)
      AR(51,I) = PCH4(I)
      AR(52,I) = PMOOH(I)
      AR(53,I) = PN2O(I)
      AR(54,I) = 1.7E-3
      AR(55,I) = PHNO3(I)
      AR(56,I) = PNO(I)
      AR(57,I) = PNO2(I)
      AR(95,I) = PHNO4(I)
      AR(101,I) = PCH3CL(I)
      AR(132,I) = PCL2(I)
      AR(133,I) = PCLO2(I)
      AR(134,I) = PHCL(I)
      AR(135,I) = PHOCL(I)
      AR(136,I) = PNOCL(I)
      AR(137,I) = PCLONO(I)
      AR(138,I) = PCLONO2(I)
      AR(142,I) = PCL2O2(I)
      AR(151,I) = PNO3(I)
      AR(153,I) = PN2O5(I)
C-AP Adding Sulfur photochemistry
      AR(156,I) = 0.
      AR(157,I) = 0.7*PSO2(I)
      AR(158,I) = PH2S(I)
      AR(186,I) = PSO21(I)
      AR(187,I) = PSO23(I)
      AR(188,I) = PH2SO4(I)
      AR(189,I) = 0. !SO3 + hv = SO2 + O
      AR(211,I) = PHO2(I)
C-KK    The following reaction has been renumbered from 218 to 182
      AR(182,I) = 0.3*PSO2(I)
c-JL ADD IODINE PHOTOLYSIS 
      AR(260,I) = PCH3I(I)
      AR(261,I) = PCH2I2(I)!/3.!divide to approx.low Temperature
      AR(262,I) = PCH2ICL(I)
      AR(263,I) = PI2(I)
      AR(264,I) = PIO(I)
      AR(265,I) = PXIO2(I)
      AR(266,I) = PIH(I)
      AR(267,I) = PINO(I)
      AR(268,I) = PINO2(I)*0.5
      AR(269,I) = PINO31(I)
      AR(292,I) = PINO32(I)
      AR(270,I) = PIHO(I)
      AR(271,I) = PICL(I)
      AR(291,I) = 0.5*PINO2(I)
      AR(417,I) = PBR2(I)
      AR(418,I) = PHBR(I)
      AR(419,I) = PBRO(I)
      AR(420,I) = PBRO2(I)
      AR(421,I) = PHOBR1(I)
      AR(422,I) = PHOBR2(I)
      AR(423,I) = PIBR(I)
      AR(441,I) = P1BRNO3(I)
      AR(442,I) = P2BRNO3(I)
      AR(444,I) = P1BRNO2(I)
      AR(445,I) = P2BRNO2(I)
      AR(453,I) = PCH3BR(I)
      AR(454,I) = PCH2BR2(I)
      AR(476,I) = PSO32(I)
      AR(477,I) = PSO31(I)      
  56  CONTINUE
      

      CALL AERCON(H2O)

c      print *,'in the main code'
c      print *,'SXIO2 after photo=',SXIO2
c      print *,'PXIO2 after photo=',PXIO2
C
C ****** TIME-DEPENDENT BOUNDARY CONDITIONS ********
C
C  UPPER BOUNDARY
C  Escape of hydrogen: VEFF(H) = (Bi/Ha)/Nt, Nt=total number density
      BOVERH = DI(LH,NZ)*DEN(NZ)/HA
      VEFF(LH) = BOVERH/DEN(NZ)
      BOVERH2 = DI(LH2,NZ)*DEN(NZ)/HA
      VEFF(LH2) = BOVERH2/DEN(NZ)
      BOVERCH4 = DI(LCH4,NZ)*DEN(NZ)/HA
      VEFF(LCH4) = BOVERCH4/DEN(NZ)
      BOVERH2O = DI(LH2O,NZ)*DEN(NZ)/HA
      VEFF(LH2O) = BOVERH2O/DEN(NZ)
C
      IF(NN.EQ.NSTEPS) write(90, 63) BOVERH,VEFF(LH),BOVERH2,VEFF(LH2)
     & ,BOVERCH4,VEFF(LCH4),BOVERH2O,VEFF(LH2O)
  63  FORMAT(/'Information on upper boundary conditions'/'BOVERH=',
     2  1PE10.3,' VEFF(LH)= ',E10.3,' BOVERH2=',
     3   E10.3,' VEFF(LH2)= ',E10.3,/'BOVERCH4= ',E10.3,' VEFF(LCH4)= '
     4  ,E10.3,' BOVERH2O- ',E10.3,' VEFF(LH2O)= ',E10.3)
C
      VCO2 = (PCO2(NZ) + PCO2D(NZ)) * HA
      SMFLUX(11) = - VCO2*CO2(NZ)*DEN(NZ)
      SMFLUX(2) = SMFLUX(11)
C
      NMP = NSTEPS - MP
      IF (NN.gt.1 .and. nn.LT.NSTEPS) GO TO 18
      write(90,97)
  97  FORMAT(//1X,'PHOTOLYSIS RATES')
      write(90,98) 
  98  FORMAT(/5X,'Z',7X,'PO2',6X,'PO2D',5X,'PCO2',5X,'PCO2D',4X,
     2  'PH2O',5X,'PO3',6X,'PO3D',5X,'PH2O2',4X,'PHCO',5X,'PH2',
     3  6X,'PHO2')
      write(90,99)(Z(I),PO2(I),PO2D(I),PCO2(I),PCO2D(I),PH2O(I),
     2  PO3(I),PO3D(I),PH2O2(I),PHCO(I),PH2(I),PHO2(I),I=1,NZ,
     3  3)
  99  FORMAT(2X,1P12E9.2)
      write(90,198)
 198  FORMAT(/5X,'Z',6X,'PCH4',5X,'PCH3OOH',2X,'PN2O',5X,'PHNO3',4X,
     2  'PNO',6X,'PNO2',5X,'PHNO4',4X,'PCCL3F',3X,'PCCL2F2',2X,
     3  'PCCL4',4X,'PCH3CL')
      write(90,99) (Z(I),PCH4(I),PMOOH(I),PN2O(I),PHNO3(I),PNO(I),
     2  PNO2(I),PHNO4(I),PCCL3F(I),PCCL2F2(I),PCCL4(I),PCH3CL(I),
     3  I=1,NZ,3)
      write(90,197)
 197  FORMAT(/5X,'Z',6X,'PMCCL3',3X,'PCL2',5X,'PHOCL',4X,'PNOCL',4X,
     2  'PCLONO',3X,'PCLONO2',2X,'PCLO2',6X,'PHCL',4x,'PNO3',5X,
     3  'PN2O5',4X,'PCL2O2')
      write(90,199) (Z(I),PMCCL3(I),PCL2(I),PHOCL(I),PNOCL(I),PCLONO(I),
     2  PCLONO2(I),PCLO2(I),PHCL(I),PNO3(I),PN2O5(I),PCL2O2(I),
     3  I=1,NZ,3)
 199  FORMAT(2X,1P12E9.2)
      write(90,298)
 298  format(/6x,'Z',6x,'PSO2',5x,'PH2S',5x,'PSO21',4x,'PSO23',4x,
     2  'PH2SO4',4x,'PCH3I',5X,'PCH2I2',4X,'PINO',4X,'PINO2',4X,
     3  'PINO31',4X,'PIH')
      write(90,299) (z(i),pso2(i),ph2s(i), pso21(i),pso23(i),ph2so4(i),
     2 PCH3I(I),PCH2I2(I),PINO(I),PINO2(I),PINO31(I),PIH(I),i=1,nz,3)
 299  format(2x,1p12e9.2)
      write(90,278)
 278  format(/6x,'Z',6x,'PIO',5x,'PCH2ICL',5x,'PIHO',4x,'PICL',4x,
     2  'PI2',6x,'PIO2',6X,'PINO32',4x,'PBR2',5X,'PHBR',5X,'PBRO',5X,
     3  'PBRO2')
      write(90,279) (z(i),PIO(I),PCH2ICL(I),PIHO(I),PICL(I),PI2(I),
     2  PXIO2(I),PINO32(I),PBR2(I),PHBR(I),PBRO(I),PBRO2(I),i=1,nz,3)
 279  format(2x,1p12e9.2)
      write(90,305)
 305  format(/6x,'Z',6x,'PHOBR1',5x,'PHOBR2',5x,'PIBR')
      write(90,306) (z(i),PHOBR1(I),PHOBR2(I),PIBR(I),i=1,nz,3)
 306  format(2x,1p4e9.2)

  18  CONTINUE

      IDO = 0
      IF (NN.EQ.NSTEPS) IDO = 1
      CALL SEDMNT(FSULF,IDO)
      DO J=1,NZ
        AERSOL(J,1) = SO4AER(J)*DEN(J)/CONVER(J,1)
      ENDDO                                                                 
C
C ***** SET UP THE JACOBIAN MATRIX AND RIGHT-HAND SIDE *****
      DO 17 J=1,LDA
      DO 17 K=1,NEQ
  17  DJAC(J,K) = 0.
      DO 19 K=1,NEQ
  19  RHS(K) = 0. 
C
C     (DJAC IS EQUAL TO (1/DT)*I - J, WHERE J IS THE JACOBIAN MATRIX)
C
C   COMPUTE CHEMISTRY TERMS AT ALL GRID POINTS
      IDO = 0
      IF (NN.EQ.NSTEPS) IDO = 1
      CALL DOCHEM(FVAL,IDO)
c      STOP
c     JL-AVOID MUTIPLE PRINT
c      stop
c      print *,'FVAL-after-DOCHEM-first-call'
c      DO I = 1,NQ
c      print *, FVAL(I,1) 
c      end do 
c  
      DO 9 I=1,NQ
      DO 9 J=1,NZ
      K = I + (J-1)*NQ
      RHS(K) = FVAL(I,J)
   9  USAVE(I,J) = USOL(I,J)
C
      DO 3 I=1,NQ
      DO 11 J=1,NZ
      R(J) = EPSJ * ABS(USOL(I,J))
  11  USOL(I,J) = USAVE(I,J) + R(J)
      CALL DOCHEM(FV,0)
C
c      print *, 'hello world-after-DOCHEM'
      DO 12 M=1,NQ
      MM = M - I + KD
      DO 12 J=1,NZ
      K = I + (J-1)*NQ
  12  DJAC(MM,K) = (FVAL(M,J) - FV(M,J))/R(J)
C
      DO 10 J=1,NZ
  10  USOL(I,J) = USAVE(I,J)
   3  CONTINUE
C
C   COMPUTE TRANSPORT TERMS AT INTERIOR GRID POINTS
      DO 13 I = 1,NQ
      DO 14 J=2,NZ1
      K = I + (J-1)*NQ
      RHS(K) = RHS(K) - DD(I,J)*USOL(I,J) 
     2  + (DU(I,J) + DHU(I,J))*USOL(I,J+1) 
     3  + (DL(I,J) - DHL(I,J))*USOL(I,J-1)      
      DJAC(KD,K) = DJAC(KD,K) + DTINV + DD(I,J)
      DJAC(KU,K+NQ) = - DU(I,J) - DHU(I,J)
  14  DJAC(KL,K-NQ) = - DL(I,J) + DHL(I,J)
  13  CONTINUE
C
C ***** LOWER BOUNDARY CONDITIONS *****
      DO 15 K=1,NQ
      U(K) = USOL(K,1)
      LB = LBOUND(K)
C
C   CONSTANT DEPOSITION VELOCITY
      IF(LB.NE.0) GO TO 16
      RHS(K) = RHS(K) + (DU(K,1) + DHU(K,1))*USOL(K,2) - DU(K,1)*U(K)
     2  - (VDEP(K)/DZ - HI(K,1)/(2.*DZ))*U(K)
      DJAC(KD,K) = DJAC(KD,K) + DTINV + DU(K,1) + VDEP(K)/DZ
     2  - HI(K,1)/(2.*DZ)
      DJAC(KU,K+NQ) = - DU(K,1) - DHU(K,1)
      GO TO 15
C
C   CONSTANT MIXING RATIO
  16  IF(LB.NE.1) GO TO 31
      RHS(K) = 0.
      DO 36 M=1,NQ
      MM = KD + K - M
  36  DJAC(MM,M) = 0.
      DJAC(KU,K+NQ) = 0.
      DJAC(KD,K) = DTINV + DU(K,1)
      GO TO 15
C
Cc   CONSTANT UPWARD FLUX
  31  CONTINUE
      RHS(K) = RHS(K) + (DU(K,1) + DHU(K,1))*USOL(K,2) - DU(K,1)*U(K)
     2   + HI(K,1)*U(K)/(2.*DZ) + SGFLUX(K)/DEN(1)/DZ
      DJAC(KD,K) = DJAC(KD,K) + DTINV + DU(K,1) + HI(K,1)/(2.*DZ)
      DJAC(KU,K+NQ) = - DU(K,1) - DHU(K,1)
  15  CONTINUE
C
C ***** UPPER BOUNDARY CONDITIONS *****
      DO 30 I=1,NQ
      U(I) = USOL(I,NZ)
      K = I + NZ1*NQ
      MB = MBOUND(I)
C
C   CONSTANT EFFUSION VELOCITY
      IF(MB.NE.0) GO TO 29
      RHS(K) = RHS(K) + (DL(I,NZ) - DHL(I,NZ))*USOL(I,NZ1) 
     2  - DL(I,NZ)*U(I) - (VEFF(I)/DZ + HI(I,NZ)/(2.*DZ))*U(I)
      DJAC(KD,K) = DJAC(KD,K) + DTINV + DL(I,NZ) + VEFF(I)/DZ
     2  + HI(I,NZ)/(2.*DZ)
      DJAC(KL,K-NQ) = - DL(I,NZ) + DHL(I,NZ)
      GO TO 30
C
C   CONSTANT DOWNWARD FLUX
  29  CONTINUE
      RHS(K) = RHS(K) + (DL(I,NZ) - DHL(I,NZ))*USOL(I,NZ1)
     2  - DL(I,NZ)*U(I) - HI(I,NZ)*U(I)/(2.*DZ) 
     3  - SMFLUX(I)/DEN(NZ)/DZ
      DJAC(KD,K) = DJAC(KD,K) + DTINV + DL(I,NZ) + HI(I,NZ)/(2.*DZ) 
      DJAC(KL,K-NQ) = - DL(I,NZ) + DHL(I,NZ)
  30  CONTINUE
C
      DO 33 J=1,NZ
      IF(Z(J).GT.ZTROP) GO TO 34
      K = 3 + (J-1)*NQ
      RHS(K) = 0.
      DO 32 M=1,NQ
      MM = M - 3 + KD
  32  DJAC(MM,K) = 0.
      DJAC(KD,K) = DTINV
      DJAC(KU,K+NQ) = 0.
      IF(J.EQ.1) GO TO 33
      DJAC(KL,K-NQ) = 0.
  33  CONTINUE
  34  CONTINUE
C
C ***** FACTOR THE JACOBIAN AND SOLVE THE LINEAR SYSTEM *****
C-JL JULY 2022 CALLING SGBCO INSTEAD OF SGBFA TO TRACK THE CONDITION NUMBER OF THE
C MATRIX,WHICH IS THE RATIO OF THE LARGEST TO THE SMALLEST EIGENVALUE.
      CALL SGBFA(DJAC,LDA,NEQ,NQ,NQ,IPVT,INDEX)
c      CALL SGBCO(DJAC,LDA,NEQ,NQ,NQ,IPVT,RCOND,INDEX)
      IF(INDEX.NE.0.) write(90,103)N,INDEX
 103  FORMAT(/1X,'N =',I3,5X,'INDEX =',I3)
      CALL SGBSL(DJAC,LDA,NEQ,NQ,NQ,IPVT,RHS,0)
C
C   COMPUTE NEW CONCENTRATIONS
      EMAX = 0.
      DO 26 I=1,NQ
      DO 26 J=1,NZ
      K = I + (J-1)*NQ
C-KK	For all runs, inc. standard O2
c-JL re-equlibrate the chemistry
      IF((I.EQ.LH2S).AND.(Z(J).GT.2.E6)) GO TO 26
      IF((I.EQ.LHSO).AND.(Z(J).GT.2.E6)) GO TO 26
      IF((I.EQ.LHS).AND.(Z(J).gt.2.E6)) GO TO 26
c      IF((I.EQ.LN2O).AND.(Z(J).GT.1.E6)) GO TO 26
c      IF((I.EQ.LCH3CL).AND.(Z(J).GT.3.E6)) GO TO 26
c      IF((I.EQ.LCH4).AND.(Z(J).GT.1.E6)) GO TO 26
c      IF((I.EQ.LH2).AND.(Z(J).GT.1.E6)) GO TO 26
c      IF((I.EQ.LCO).AND.(Z(J).GT.1.E6)) GO TO 26
c      IF((I.EQ.LH2O).AND.(Z(J).GT.1.E6)) GO TO 26
c      IF((I.EQ.LO3).AND.(Z(J).GT.1.E5)) GO TO 26
c      IF((I.EQ.LHNO3).AND.(Z(J).GT.9.E6)) GO TO 26
c      IF((I.EQ.LH2O2).AND.(Z(J).eq.1.2E6)) GO TO 26
c      IF((I.EQ.LNO2).AND.(Z(J).GT.5.E4)) GO TO 26
c      IF((I.EQ.LO).AND.(Z(J).GT.1.E6)) GO TO 26
c      IF((I.EQ.LH2CO).AND.(Z(J).GT.9.E6)) GO TO 26
c      IF((I.EQ.LHSO).AND.(Z(J).GT.3.E6)) GO TO 26
c      IF((I.EQ.LNO).AND.(Z(J).GT.2.E6)) GO TO 26
c      IF((I.EQ.LH2SO4).AND.(Z(J).GT.1.E6)) GO TO 26
c      IF((I.EQ.LS).AND.(Z(J).GT.1.E6)) GO TO 26
c      IF((I.EQ.LCH3OOH).AND.(Z(J).GT.1.E6)) GO TO 26 
c      IF((I.EQ.LSO2).AND.(Z(J).GT.1.E6)) GO TO 26
c      IF((I.EQ.LNO3).AND.(Z(J).GT.9.E6)) GO TO 26
c      IF((I.EQ.LHCL).AND.(Z(J).GT.1.E6)) GO TO 26
c      IF((I.EQ.LHNO2).AND.(Z(J).GT.1.E6)) GO TO 26
c      IF((I.EQ.LOH).AND.(Z(J).GT.1.E4)) GO TO 26
c      IF((I.EQ.LHO2).AND.(Z(J).GT.1.E5)) GO TO 26
c      IF((I.EQ.LCLONO2).AND.(Z(J).GT.9.E6)) GO TO 26
c      IF((I.EQ.LCL).AND.(Z(J).GT.1.E5)) GO TO 26
      IF((I.EQ.LHOCL).AND.(Z(J).GT.9.E6)) GO TO 26
c      IF((I.EQ.LCLO).AND.(Z(J).GT.8.6E6)) GO TO 26
c      IF((I.EQ.LCH3O2).AND.(Z(J).GT.8.E6)) GO TO 26
c-JL:ONLY I2,IO,CH3I,CH2ICL,CH2I2 HAS CONCENTRATION MEASUREMENT
c      IF((I.EQ.LI).AND.(Z(J).GT.8.E6)) GO TO 26
      IF((I.EQ.LI2).AND.(Z(J).gt.6.E6)) GO TO 26
c      IF((I.EQ.LIH).AND.(Z(J).gt.7.E6)) GO TO 26
c      IF((I.EQ.LIO).AND.(Z(J).GT.8.E6)) GO TO 26
c      IF((I.EQ.LIHO).AND.(Z(J).GT.7.E6)) GO TO 26
      IF((I.EQ.LIO2).AND.(Z(J).GT.7.E6)) GO TO 26
c      IF((I.EQ.LINO).AND.(Z(J).GT.9.E6)) GO TO 26
      IF((I.EQ.LICL).AND.(Z(J).GT.7.E6)) GO TO 26
      IF((I.EQ.LI2O2).AND.(Z(J).gt.6.E6)) GO TO 26
      IF((I.EQ.LI2O3).AND.(Z(J).gt.6.E6)) GO TO 26
      IF((I.EQ.LI2O4).AND.(Z(J).gt.6.E6)) GO TO 26
      IF((I.EQ.LINO2).AND.(Z(J).GT.8.E6)) GO TO 26
      IF((I.EQ.LINO3).AND.(Z(J).gt.7.E6)) GO TO 26
c      IF((I.EQ.LCL).AND.(Z(J).GT.5.E6)) GO TO 26
      IF((I.EQ.LCH3I).AND.(Z(J).gt.8.E6)) GO TO 26
      IF((I.EQ.LCH2ICL).AND.(Z(J).gt.3.E6)) GO TO 26
      IF((I.EQ.LCH2I2).AND.(Z(J).gt.7.E6)) GO TO 26
c      IF((I.EQ.LCH2I).AND.(Z(J).gt.1.0E4))GO TO 26 
      IF((I.EQ.LCLONO2).AND.(Z(J).GT.8.E6)) GO TO 26
c      IF((I.EQ.LCL2O2).AND.(Z(J).GT.1.E6))GO TO 26
c      IF((I.EQ.LCL2O).AND.(Z(J).GT.1.E6))GO TO 26
c      IF((I.EQ.LCL2).AND.(Z(J).GT.1.E6))GO TO 26
      IF((I.EQ.LN2O5).AND.(Z(J).gt.7.E6))GO TO 26
      IF((I.EQ.LHO2NO2).AND.(Z(J).GT.9.E6))GO TO 26
c      IF((I.EQ.LICL).AND.(Z(J).GT.7.E6))GO TO 26
      IF((I.EQ.LHOBR).AND.(Z(J).gt.8.E6))GO TO 26
c      IF((I.EQ.LBRO2).AND.(Z(J).gt.5.E6))GO TO 26
c      IF((I.EQ.LBR2).AND.(Z(J).gt.4.E6))GO TO 26
c      IF((I.EQ.LIBR).AND.(Z(J).gt.5.E6))GO TO 26
c      IF((I.EQ.LBRNO2).AND.(Z(J).gt.8.E6))GO TO 26
      IF((I.EQ.LBRNO3).AND.(Z(J).gt.6.E6))GO TO 26       
      REL(I,J) = RHS(K)/USOL(I,J)
      EREL = ABS(REL(I,J))
      EMAX = AMAX1(EMAX,EREL)
      IF(EREL.LT.EMAX) GO TO 26
      IS = I
      JS = J
      UMAX = USOL(I,J)
      RMAX = RHS(K)
  26  USOL(I,J) = USOL(I,J) + RHS(K)
C
      DO 4 J=1,NZ
      IF(Z(J).LT.ZTROP) USOL(3,J) = H2O(J)
   4  CONTINUE

C-AP Adding tridiagonal solver
C       TRIDIAGONAL INVERSION *****
      L=1
      I = NQ + L
c-JL  IF(I.EQ.LSO4AER) MZ = 50
      MZ = 50
C-AP      IF(I.EQ.LS8TESTAER) MZ = 40
C-AP      IF(I.EQ.LHCAER) MZ = NZ
      MZ1 = MZ - 1
      MZP1 = MZ + 1
C
C   COMPUTE ADVECTION TERMS FOR PARTICLES
      DPU(1,L) = WFALL(2,L)*DEN(2)/DEN(1)/(2.*DZ)
      DPL(NZ,L) = WFALL(NZ1,L)*DEN(NZ1)/DEN(NZ)/(2.*DZ)
      DO 38 J=2,NZ1
      DPU(J,L) = WFALL(J+1,L)*DEN(J+1)/DEN(J)/(2.*DZ)
  38  DPL(J,L) = WFALL(J-1,L)*DEN(J-1)/DEN(J)/(2.*DZ)
C                                                                              
C
C   TA = LOWER DIAGONAL, TB = DIAGONAL, TC = UPPER DIAGONAL, TY =
C   RIGHT-HAND SIDE
      DO 70 J=1,NZ
      TA(J) = 0.
      TB(J) = 0.
      TC(J) = 0.
  70  TY(J) = 0.
C
      DO 44 J=1,MZ
      TB(J) = YL(I,J)
  44  TY(J) = YP(I,J)/DEN(J)
C
      DO 45 J=2,MZ1
      TA(J) = - DL(I,J) + DPL(J,L)
      TB(J) = TB(J) + DD(I,J)
  45  TC(J) = - DU(I,J) - DPU(J,L)
C                                                                              
C   BOUNDARY CONDITIONS
      TA(MZ) = - DL(I,MZ) + DPL(MZ,L)
      TB(MZ) = TB(MZ) + DL(I,MZ) + 0.5*WFALL(MZ,L)/DZ
      TB(1) = TB(1) + DU(I,1) + (.01 - 0.5*WFALL(1,L))/DZ
      TC(1) = - DU(I,1) - DPU(1,L)
C
      CALL SGTSL(MZ,TA,TB,TC,TY,NFLAG)
      IF (NFLAG.NE.0) write(90,401) N,NFLAG,I
 401  FORMAT(//1X,'TRIDIAGONAL SOLVER FAILED AT N =',I3,2X,
     2  'NFLAG =',I2,2X,'SPECIES #',I2)
C
      IF(I.EQ.LSO4AER) THEN
        DO 59 J=1,MZ
   59     SO4AER(J) = TY(J)
C-AP      ELSEIF(I.EQ.LS8AER) THEN
C-AP        DO 46 J=1,MZ
C-AP   46     S8(J) = TY(J)
C-AP      ELSEIF(I.EQ.LHCAER) THEN
C-AP        DO 60 J=1,MZ
C-AP          HCAER(J) = TY(J)
C-AP   60   CONTINUE
      ENDIF
C
C   FILL UP UPPER PORTION WITH APPROXIMATE ANALYTIC SOLUTION
      IF(I.EQ.LSO4AER .AND. MZ.NE.NZ) THEN
        DO 61 J=MZP1,NZ
          SO4AER(J) = SO4AER(J-1) * EXP(-WFALL(J,L)*DZ/EDD(J))
   61     SO4AER(J) = AMAX1(SO4AER(J),1E-100)
C-AP      ELSEIF(I.EQ.LS8AER .AND. MZ.NE.NZ) THEN
C-AP        DO 47 J=MZP1,NZ
C-AP          S8(J) = S8(J-1) * EXP(-WFALL(J,L)*DZ/EDD(J))
C-AP  47      S8(J) = AMAX1(S8(J),1E-100)
C-AP      ELSEIF(I.EQ.LHCAER .AND. MZ.NE.NZ) THEN
C-AP        DO 62 J=MZP1,NZ
C-AP          HCAER(J) = HCAER(J-1) * EXP(-WFALL(J,L)*DZ/EDD(J))
C-AP          HCAER(J) = AMAX1(HCAER(J),1E-100)
C-AP   62   CONTINUE
      ENDIF
C-AP   58 CONTINUE
C-JL defines DTSAVE earlier as it skips 2010
      DTSAVE = DT     
c      print *,'DT ='
c      print *, DT
c      write(90,*)
      if(NN.eq.NSTEPS) GOTO 2010
C   AUTOMATIC TIME STEP CONTROL
      DTSAVE = DT
c      DTSAVE = 1.0E-4
      IF(EMAX.GT.0.20)  DT = 0.7*DTSAVE
      IF(EMAX.GT.0.15)  DT = 0.9*DTSAVE
      IF(EMAX.LT.0.10)  DT = 1.1*DTSAVE
      IF(EMAX.LT.0.05)  DT = 1.3*DTSAVE
      IF(EMAX.LT.0.03)  DT = 1.5*DTSAVE
      IF(EMAX.LT.0.01)  DT = 2.0*DTSAVE
      IF(EMAX.LT.0.003) DT = 5.0*DTSAVE
      IF(EMAX.LT.0.001) DT = 10.*DTSAVE
c      print *,' DTSAVE='
c      print *, DTSAVE
c      print *, 'DT ='
c      print *, DT 
c Adjusting time step to assure that TIME<=TSTOP
      TIME1 = TIME + DT
      if(TIME1.ge.TSTOP) then
        DT = ABS(TIME-TSTOP)
        NN = NSTEPS -1
      endif

      DTINV = 1./DT
C
2010  ISP = ISPEC(IS)
      ZMAX = Z(JS)
      IF(SM-MS.GT.0.01) GO TO 317
      write(90,100)N,EMAX,ISP,ZMAX,
     & UMAX,RMAX,DT,TIME
 100  FORMAT(1X,'N =',I4,2X,'EMAX =',1PE9.2,' FOR ',A8,
     2  'AT Z =',E9.2,1X,'U =',E9.2,1X,'RHS =',E9.2,
     3  2X,'DT =',E9.2,2X,'TIME =',E9.2)
C-AP
C   COMPUTE ATMOSPHERIC OXIDATION STATE
      DO 42 I=1,NQ
      SR(I) = 0.
      DO 43 J=1,JTROP
  43  SR(I) = SR(I) + RAINGC(I,J)*USOL(I,J)*DEN(J)*DZ
      PHIDEP(I) = VDEP(I)*USOL(I,1)*DEN(1)
  42  TLOSS(I) = SR(I) + PHIDEP(I)
C
      SR(LSO4AER) = 0.
      DO 48 J=1,JTROP
      SR(LSO4AER) = SR(LSO4AER) + RAINGC(LH2SO4,J)*SO4AER(J)*DEN(J)*DZ
  48  CONTINUE
      PHIDEP(LSO4AER) = (WFALL(1,1) + .01) * SO4AER(1) * DEN(1)
      TLOSS(LSO4AER) = SR(LSO4AER) + PHIDEP(LSO4AER)
C
C   COMPUTE SULFUR BUDGET AND READJUST SO2 (H2S) OUTGASSING RATE IF SO
C   DESIRED (PROGRAM IS SET UP FOR PURE SO2 OUTGASSING)
      SLOSS = TLOSS(LH2S) + TLOSS(LHS) + TLOSS(LSO) +
     2  TLOSS(LSO2) + TLOSS(LH2SO4) + TLOSS(LHSO) + 
     3  TLOSS(LSO4AER)
      SLOSSP = SLOSS - TLOSS(LSO2)
      IF (ISULF.EQ.0 .OR. TIME.LT.1.E6) GO TO 316
      IF (LBOUND(LSO2).EQ.2) SGFLUX(LSO2) = SGFLUX(LSO2) * VOLFLX/SLOSS
      IF (LBOUND(LH2S).EQ.2) SGFLUX(LH2S) = SGFLUX(LH2S) * VOLFLX/SLOSS
 316  CONTINUE
C
 317  CONTINUE
C
C   RETRY TIME STEP IF EMAX EXCEEDS 30 PERCENT
      IF(EMAX.LT.0.3) GO TO 28
      write(90,*)'RETRY TIME STEP BECAUSE EMAX=',EMAX
      DT = 0.5*DTSAVE
      TIME = TIME - DTSAVE
      if(TIME.lt.0) TIME = 0.
      DO 27 I=1,NQ
      DO 27 J=1,NZ
  27  USOL(I,J) = USAVE(I,J)
  28  CONTINUE
C
      NS = N/NPR
      SN = N/PRN
      IF(NN.EQ.NSTEPS) SN = NS
      IF(SN-NS.GT.1.E-4) GO TO 37
C
      write(90,*)
      write(90,*)'BEFOREOUT'
      write(90,*) 'N=',N,'NN=',NN,'SN=',SN,'NS=',NS
c-JL track the total gas-phase iodine
c-JL IY = I + IO + IO2 + IH + IHO + INO + INO2 + INO3 + 2*I2 + ICL +
C-JL 2*I2O2 + 2*I2O3 + 2*I2O4 
c      Do I = 1, NZ 
c
c     print *,'IY ='
c     print *, IY
      CALL OUTPUTP(NN,NSTEPS,TIME,FLOW)
c      
      OPEN(unit=81,file= DIRIO//'/atm_composition.out')
      WRITE(81,399) USOL,T,EDD,DEN,SO4AER,AERSOL,WFALL,RPAR
 399  FORMAT(1P8E12.5)
      close(81)
c      
  37  CONTINUE
      IF(INDEX.NE.0) STOP
      IF(NN.EQ.NSTEPS) GO TO 22
      IF(TIME.GE.TSTOP) NN = NSTEPS - 1
      if(TIME.lt.TSTOP.and.N.eq.NSTEPS) then
       write(*,'(A,I4,A)')'Time not reached after',NSTEPS,
     &  ' of the photochemical model. The run is stopping now.'
c-JL temporaily let it not stop 
       STOP
      endif
          
   1  CONTINUE      
     
C ***** END THE TIME-STEPPING LOOP *****

  22  CONTINUE
      if(ICOUPLe.eq.1) NSTEPS =N

c      OPEN(unit=81,file= DIRIO//'/atm_composition.out')
c      WRITE(81,399) USOL,T,EDD,DEN,SO4AER,AERSOL,WFALL,RPAR
c 399  FORMAT(1P8E12.5)
c      close(81) 
        

c Transfer results to the climate model (ICOUPLE=1)
      if (ICOUPLE.eq.1) then
       DO 255 I=1,NZ
c Transfer O3 and H2O
        WRITE(84,254) Z(I),PRESS(I),O3(I),H2O(I) 
 254    FORMAT(1PE10.3,3(E10.2))
 255   CONTINUE
       close(84)
      endif
C-KK  Need to find coldtrap by locating water mixing ratio minimum. 

	Jcold = 0

	DO J = 1, NZ
 	   IF (JCOLD .EQ. 0) THEN
           IF (T(J) .LT. T(J+1)) JCOLD = J
	   END IF
	END DO

	OPEN(unit=19,file= DIRIO//'/mixing_ratios.out')
c     Transfer surface mixing ratios
        WRITE(19,*) FAR
	WRITE(19,*) USOL(LCH4,1) 
	WRITE(19,*) FCO2
	WRITE(19,*) O2(1)
	WRITE(19,*) Jcold
        WRITE(19,*) O3COL
       close(19)
c
C   The following WRITEs out the o3 mixing ratio values so that the 
c   profiles can be compared
C
c      DO 333 I=1,NZ
c        WRITE(15,332) O3(I),Z(I)
c 332  FORMAT(E10.2,1X,1PE9.3)
c 333  CONTINUE 
C   The following WRITEs out the temperature and altitude so that 
C   the profiles can be compared.
C
c      DO 367 I=1,NZ
c	WRITE(14,366) T(I),Z(I)
c 366  FORMAT(1PE9.3,1X,1PE9.3)
c 367  CONTINUE     
c
c   MaKe file for plots
c-as Not needed for now
c      WRITE(10,699)
c 699  format(2x,'Alt',6x,'O',10x,'O3',9x,'CH4',8x,'CO',9x,'N2O',8x,
c     1  'CH3Cl',6x,'n(OH)',6x,'n(O1D)',5x,'PO2',8x,'PO3D')  
c      do 700 i=1,nz
c      zkm = z(i)/1.e5
c      po2tot = po2(i) + po2d(i)
c 700  WRITE(10,701) zkm,usol(2,i),usol(7,i),usol(10,i),usol(11,i),
c     1  usol(14,i),usol(23,i),sl(4,i),sl(31,i),po2tot,po3d(i)
c 701  format(f5.1,1x,1p10e11.4)
      GO TO 21
  20  write(90,300)I
 300  FORMAT(//1X,'NMAX EXCEEDED FOR SPECIES ',I3)
      GO TO 21
  25  write(90,301)IERR
 301  FORMAT(//1X,'ERROR IN REACTION ',I3)
C
  21  CONTINUE
      STOP
      END program atm_chem

c---------------------------------------------------------------


      SUBROUTINE OUTPUTP(N,NSTEPS,TIME,FLOW)
       INCLUDE 'INCLUDECHEM/parNZ.inc'
       INCLUDE 'INCLUDECHEM/parNQ_NQT.inc'
       INCLUDE 'INCLUDECHEM/parNR.inc'
       INCLUDE 'INCLUDECHEM/parNF.inc'
       INCLUDE 'INCLUDECHEM/parNSP_NSP1_NSP2.inc'
       INCLUDE 'INCLUDECHEM/parNMAX.inc'
      INCLUDE 'INCLUDECHEM/comDIRP.inc'
      INCLUDE 'INCLUDECHEM/comABLOK.inc'
      INCLUDE 'INCLUDECHEM/comBBLOK.inc'
      INCLUDE 'INCLUDECHEM/comCBLOK.inc'
      INCLUDE 'INCLUDECHEM/comDBLOK.inc'
      INCLUDE 'INCLUDECHEM/comFBLOK1.inc'
      INCLUDE 'INCLUDECHEM/comNBLOK.inc'
      INCLUDE 'INCLUDECHEM/comSULBLK.inc'
      INCLUDE 'INCLUDECHEM/comZBLOK.inc'
      INCLUDE 'INCLUDECHEM/comAERBLK.inc'
      INCLUDE 'INCLUDECHEM/comSATBLK.inc'
      INCLUDE 'INCLUDECHEM/comRRATS.inc'
c in may 10 2019, JL include Rblcok for JCHEM
      INCLUDE 'INCLUDECHEM/comRBLOK.inc'
c-JL includes Pressure for several iodine chemistry 
      INCLUDE 'INCLUDECHEM/comPRESS1.inc'
c-JL Oct 2022 tracking GFLUX
      INCLUDE 'INCLUDECHEM/comFLUXPHOTO.inc'
c in may 10 2019, JL include chem; other two are place holder
      CHARACTER*30 CHEM(5,NR),PRODRX(NSP,NR),LOSSRX(NSP,NR)  
      DIMENSION FUP(NQT),FLOW(NQT),CON(NQT),FLUXCH(NQT,NZ)
     2  ,ZF(NZ),YI(NZ),ROS(NZ)
C
c in may 10 2019, to include primo3s to this subroutine
      OPEN(unit=61, file= 'DATA'//'/primo3s.chm', status='old')
C
      ISKIP = 4
      JSKIP = ISKIP
      IF(N.EQ.NSTEPS) ISKIP = 2
      TIMEY = TIME/3600./24./365.
      write(90,100)TIME,TIMEY
 100  FORMAT(/1X,'TIME =',E11.4,5X,'TIMEY =',1pe13.4,1X,'YEARS')
      write(90,101)NPHOT
 101  FORMAT(/1X,'NPHOT =',I3)
C
      write(90,105)
 105  FORMAT(/1X,'JL-MIXING RATIOS OF LONG-LIVED SPECIES'/)
      IROW = 12
      LR = NQ/IROW + 1
      RL = FLOAT(NQ)/IROW + 1
      DIF = RL - LR
      IF (DIF.LT.0.001) LR = LR - 1
C
      DO 8 L=1,LR
      K1 = 1 + (L-1)*IROW
      K2 = K1 + IROW - 1
      IF (L.EQ.LR) K2 = NQ
      write(90,110) (ISPEC(K),K=K1,K2)
 110  FORMAT(/5X,'Z',8X,13(A8,1X))
      DO 20 I=1,3
  20  write(90,120) Z(I),(USOL(K,I),K=K1,K2)
      DO 21 I=4,NZ,ISKIP
  21  write(90,120) Z(I),(USOL(K,I),K=K1,K2)
 120  FORMAT(1X,1P13E9.2)

      IF (N.EQ.0) GO TO 8
      write(90,140)
 140  FORMAT(/1X,'TP, TL')
      write(90,145)(TP(K),K=K1,K2)
      write(90,145)(TL(K),K=K1,K2)
 145  FORMAT(10X,1P12E9.2)
   8  CONTINUE
C
C-JL
      Do J = 1, NZ
      YI(J) = USOL(LIO,J) + USOL(LIO2,J) + USOL(LIH,J) +USOL(LI,J)
     2  + USOL(LIHO,J)+USOL(LINO,J) + USOL(LINO2,J) + USOL(LINO3,J)
     3  + 2.*USOL(LI2,J) + USOL(LICL,J) + 2.*USOL(LI2O2,J)
     4  + 2.*USOL(LI2O3,J) + 2.*USOL(LI2O4,J)+USOL(LIBR,J)
      ROS(J)= USOL(LOH,J)+USOL(LHO2,J)+USOL(LH2O2,J)+USOL(LO,J)
     2  + USOL(LO1D,J)+USOL(LO21S,J)+USOL(LO21D,J)
      END DO
c
      write(90,106)
 106  FORMAT(//1X,'MIXING RATIO OF AEROSOL AND TOTAL-IODINE'/)
      write(90,185)
 185  FORMAT(5X,'Z',6X,'SO4AER',3X,'TOTAL-I',4x,'ROS')
      DO 18 J=1,3
  18  write(90,182) Z(J),SO4AER(J),YI(J),ROS(J)
      DO 19 J=4,NZ,ISKIP
  19  write(90,182) Z(J),SO4AER(J),YI(J),ROS(J)
 182  FORMAT(1X,1P4E9.2)
C-AP 
      IF (N.EQ.0) RETURN
      write(90,183) TP(LSO4AER)
      write(90,184) TL(LSO4AER)
 183  FORMAT(/2X,'TP',6X,1P1E9.2)
 184  FORMAT(2X,'TL',6X,1P1E9.2)
C
c      write(90,107)
c 107  format(//1x,'TOTAL-GAS-PHASE-IODINE'/)
c      WRITE(90,108)
c 108  FORMAT(5X,'Z',6X,'IY')
c      DO 256 Y = 1,NZ
c      WRITE(90,256) Z(Y),IY(Y)
c 256  FORMAT(1X,1P2E9.2)
c
c      O3_ATMCM = O3COL/2.687e19
c- April 2025 JL: previously it was defined as 2.6E16...I can't track
c the source of that error. 
      O3_ATMCM = O3COL/2.687e16
c      CALL PHOTO
      UVC = GFLUX(1)+GFLUX(2)+GFLUX(3)+GFLUX(4)+GFLUX(5)+GFLUX(6)+
     2 GFLUX(7)+GFLUX(8)+GFLUX(9)+GFLUX(10)+GFLUX(11)+GFLUX(12)+
     3 GFLUX(13)+ GFLUX(14)+GFLUX(15)+GFLUX(16)+GFLUX(17)+GFLUX(18)+
     2 GFLUX(19)+GFLUX(20)+GFLUX(21)+GFLUX(22)+GFLUX(23)+
     3 GFLUX(24) +GFLUX(25)+GFLUX(26)+GFLUX(27)+GFLUX(28)+
     4 GFLUX(29)+GFLUX(30)+GFLUX(31)+GFLUX(32)+GFLUX(33)+GFLUX(34)
     5 +GFLUX(35)+GFLUX(36)+GFLUX(37)+GFLUX(38)+GFLUX(39)+
     6 GFLUX(40)+GFLUX(41)+GFLUX(42)+GFLUX(43)
      UVB = GFLUX(43)+GFLUX(44)+GFLUX(45)+GFLUX(46)+
     2 GFLUX(47)+GFLUX(48)+GFLUX(49)+GFLUX(50)+
     3 GFLUX(51)
      UVA = GFLUX(51)+GFLUX(52)+GFLUX(53)+GFLUX(54)+GFLUX(55)
     2 +GFLUX(56)+GFLUX(57)+GFLUX(58)+GFLUX(59)+GFLUX(60)+
     3 GFLUX(61)+GFLUX(62)+GFLUX(63)
      VIS = GFLUX(64)+GFLUX(65)+GFLUX(66)+GFLUX(67)+GFLUX(68)+GFLUX(69)
     2 +GFLUX(70)+GFLUX(71)+GFLUX(72)+GFLUX(73)+GFLUX(74)+GFLUX(75)+
     3 +GFLUX(76)+GFLUX(77)+GFLUX(78)+GFLUX(79)+GFLUX(80)+GFLUX(81)+
     4 GFLUX(82)+GFLUX(83)+GFLUX(84)+GFLUX(85)+GFLUX(86)+GFLUX(87)
     5 +GFLUX(88)+GFLUX(89)+GFLUX(90)+GFLUX(91)+GFLUX(92)+GFLUX(93)
     6 +GFLUX(94)+GFLUX(95)+GFLUX(96)+GFLUX(97)+GFLUX(98)+GFLUX(99)
     7 +GFLUX(100)+GFLUX(101)+GFLUX(102)+GFLUX(103)+GFLUX(104)+
     8 GFLUX(105)+GFLUX(106)+GFLUX(107)+GFLUX(108)

      write(90,150) O3COL,REAL(IOCOL),REAL(CH4COL)
 150  FORMAT(//1X,'OZONE COLUMN DEPTH = ',1PE11.4,1x,'IO Column Depth= 
     & ',1PE11.4,1x,'CH4 Column Depth = ',1PE11.4)
      write(90,401) UVC
 401  FORMAT(//1X,'UV-C(w/m2) at surface = ',1PE11.4)
      write(90,402) UVB
 402  FORMAT(1X,'UV-B(w/m2) at surface = ',1PE11.4)
      write(90,403) UVA
 403  FORMAT(1X,'UV-A(w/m2) at surface = ',1PE11.4)
      write(90,404) VIS
 404  FORMAT(1X,'VISIBLE(w/m2) at surface = ',1PE11.4)
      write(90,1150) O3_ATMCM
 1150 FORMAT(1X,'OZONE COLUMN DEPTH In Dobson Unit = ',1PE11.4,' DU')
c      write(90,1151) IOCOL
c 1151 FORMAT(//1X,'IO COLUMN DEPTH = ',1PE11.3)     
C-AP
      write(90,152) H2SCOL,SO2COL
 152  FORMAT(/1X,'SULFUR COLUMN DEPTHS:  H2S =',1PE10.3,2X,'SO2 =',
     2  E10.3,2X)
C-AP
	DO i = 1, NZ
	 IF (USOL(3,i) .LT. USOL(3,i+1)) THEN
		JCOLD = i
		GOTO 352
	 END IF
	END DO
 352  CONTINUE
      write(90,151) JCOLD, USOL(3,JCOLD)
 151  FORMAT(/1X,I3,' FH2O AT COLD TRAP =',1PE10.3)
      IF(N.LT.NSTEPS) RETURN
C
C ***** PRINT ON LAST ITERATION ONLY *****
      DO 1 I=1,NZ
   1  ZF(I) = Z(I) + 0.5*DZ
C
      DO 3 K=1,NQ
      DO 2 I=1,NZ
   2  SL(K,I) = USOL(K,I)*DEN(I)
      DO 4 I=1,NZ1
   4  FLUXCH(K,I) = - DK(K,I)*(USOL(K,I+1) - USOL(K,I))/DZ
   3  CONTINUE
C
      K = LSO4AER
      J = 1
      DO 5 I=1,NZ1
      FLUXCH(K,I) = -DK(K,I)*(SO4AER(I+1) - SO4AER(I))/DZ
     2  - 0.5*(WFALL(I,J)*DEN(I)*SO4AER(I) + WFALL(I+1,J)*DEN(I+1)
     3         *SO4AER(I+1))
   5  CONTINUE
C
      DO 15 K=1,NQT
      FLOW(K) = FLUXCH(K,1) - (YP(K,1) - YL(K,1)*SL(K,1))*DZ
      FUP(K) = FLUXCH(K,NZ1) + (YP(K,NZ) - YL(K,NZ)*SL(K,NZ))*DZ
      CON(K) = TP(K) - TL(K) + FLOW(K) - FUP(K)
 502  format('K=',I2,' FLOW(K)=',1PE10.3,' FUP(K)=',E10.3)
  15  CONTINUE

C-AP
      FLOW(3) = FLUXCH(3,11)
      CON(3) = TP(3) - TL(3) + FLOW(3) - FUP(3)
      DO 6 I=1,10
   6  FLUXCH(3,I) = 0.
C
      write(90,125)
 125  FORMAT(/1X,'NUMBER DENSITIES OF LONG-LIVED SPECIES'/)
      DO 9 L=1,LR
      K1 = 1 + (L-1)*IROW
      K2 = K1 + IROW - 1
      IF (L.EQ.LR) K2 = NQ
      write(90,110) (ISPEC(K),K=K1,K2)
      DO 22 I=1,NZ,ISKIP
       write(90,120) Z(I),(SL(K,I),K=K1,K2)
c      if ((LO3.GE.K1).AND.(LO3.LE.K2)) WRITE(83,355) Z(I),SL(LO3,I)
  22  CONTINUE
   9  CONTINUE
 355  FORMAT(1PE10.3,1PE12.3)
c     close(83)

      ISKIP = 4
      write(90,155)
 155  FORMAT(/1X,'FLUXES OF LONG-LIVED SPECIES'/)
      ZFL = 0.
      ZFT = ZF(NZ)
      DO 10 L=1,LR
      K1 = 1 + (L-1)*IROW
      K2 = K1 + IROW - 1
      IF (L.EQ.LR) K2 = NQT
C-AP      IF (L.EQ.LR) K2 = NQ
      write(90,110) (ISPEC(K),K=K1,K2)
      write(90,120) ZFL,(FLOW(K),K=K1,K2)
      DO 23 I=1,NZ,ISKIP
  23  write(90,120) ZF(I),(FLUXCH(K,I),K=K1,K2)
      write(90,120) ZFT,(FUP(K),K=K1,K2)
  10  CONTINUE
C
      write(90,175)
 175  FORMAT(/1X,'RAINOUT RATE, PHIDEP, TLOSS AND LOWER B.C.'/)
      write(90,176)
 176  FORMAT(1X,'FOLLOWED BY TP, TL, FUP, FLOW, CON'/)
      DO 13 L=1,LR
      K1 = 1 + (L-1)*IROW
      K2 = K1 + IROW - 1
c-JL      IF (L.EQ.LR) K2 = NQT
      IF (L.EQ.LR) K2 = NQ
      write(90,110) (ISPEC(K),K=K1,K2)
      write(90,145) (SR(K),K=K1,K2)
      write(90,145)(PHIDEP(K),K=K1,K2)
      write(90,145)(TLOSS(K),K=K1,K2)
      write(90,146) (LBOUND(K),K=K1,K2)
 146  FORMAT(14X,12(I1,8X))
      write(90,145)
      write(90,145) (TP(K),K=K1,K2)
      write(90,145) (TL(K),K=K1,K2)
      write(90,145) (FUP(K),K=K1,K2)
      write(90,145) (FLOW(K),K=K1,K2)
      write(90,145) (CON(K),K=K1,K2)     
  13  CONTINUE

C-AP 175  FORMAT(/1X,'RAINOUT OF LONG-LIVED SPECIES'/)
C-AP      DO 13 L=1,LR
C-AP      K1 = 1 + (L-1)*IROW
C-AP      K2 = K1 + IROW - 1
C-AP      IF (L.EQ.LR) K2 = NQ
C-AP      PRINT 110, (ISPEC(K),K=K1,K2)
C-AP  13  PRINT 145,(SR(K),K=K1,K2)
C-AP
C
C   COMPUTE CONSERVATION OF SULFUR
      SULDEP = - (FLOW(LHS) + FLOW(LSO) + FLOW(LH2SO4)
     2  + FLOW(LHSO) + FLOW(LSO4AER))
      IF (LBOUND(LSO2).EQ.0) SULDEP = SULDEP - FLOW(LSO2)
      IF (LBOUND(LH2S).EQ.0) SULDEP = SULDEP - FLOW(LH2S)
      SULRAN = SR(LH2S) + SR(LHS) + SR(LSO) + SR(LSO2) +
     2  SR(LH2SO4) + SR(LHSO) + SR(LSO4AER) 
      SULLOS = SULDEP + SULRAN
      SULPRO = 0.
      IF (LBOUND(LSO2).NE.0) SULPRO = SULPRO + FLOW(LSO2)
      IF (LBOUND(LH2S).NE.0) SULPRO = SULPRO + FLOW(LH2S)
      SO4LOS = TLOSS(LH2SO4) + TLOSS(LSO4AER)
      write(90,177) SULLOS,SULPRO,SO4LOS
 177  FORMAT(/1X,'CONSERVATION OF SULFUR:',/5X,'SULLOS =',1PE10.3,
     2  2X,'SULPRO =',E10.3,2X,'SO4LOS =',E10.3)
C-AP
      write(90,179)
  179 FORMAT(/1X,'INTEGRATED REACTION RATES'/)
C      write(90,180) RAT
C  180 FORMAT(1X,1P10E10.3)
C
      WRITE(90,181)
      IROW = 10
      LR = NR/IROW + 1
      RL = FLOAT(NR)/IROW + 1
      DIF = RL - LR
      IF (DIF.LT.0.001) LR = LR - 1
C
      DO 17 L=1,LR
      K1 = 1 + (L-1)*IROW
      K2 = K1 + IROW - 1
      IF (L.EQ.LR) THEN
      K2 = NR
c-JL comment out the next write statement to allow the rest of the 
c-JL code flow. Yet the integrated reaction rate of 281-289 is not 
c-JL printed. 
c        WRITE(90,186) K1,(RAT(K),K=K1,K2),K2
c  186   FORMAT(I3,2X,1P10E10.3,2X,I3)
        GO TO 17
      ENDIF
      WRITE(90,180) K1,(RAT(K),K=K1,K2),K2
  180 FORMAT(I3,2X,1P10E10.3,2X,I3)
   17 CONTINUE
      WRITE(90,181)
  181 FORMAT(9X,'1',9X,'2',9X,'3',9X,'4',9X,'5',9X,'6',9X,'7',9X,
     2    '8',9X,'9',8X,'10')
c
      write(90,160)
 160  FORMAT(/1X,'ATMOSPHERIC PARAMETERS AND PH EQ SPECIES')
      NPE = NSP - NQ
      NQ1 = NQ + 1
      LR = NPE/IROW + 1
      RL = FLOAT(NPE)/IROW + 1
      DIF = RL - LR
      IF (DIF.LT.0.001) LR = LR - 1
C
      DO 12 L=1,LR
      K1 = NQ1 + (L-1)*IROW
      K2 = K1 + IROW - 1
      IF (L.EQ.LR) K2 = NSP
      write(90,110) (ISPEC(K),K=K1,K2)
      DO 24 I=1,NZ,ISKIP
  24  write(90,120) Z(I),(SL(K,I),K=K1,K2)
  12  CONTINUE
C
c-JL
c      Do J = 1, NZ
c      YI(J) = USOL(LI,J) + USOL(LIO,J) + USOL(LIO2,J) + USOL(LIH,J) 
c     2  + USOL(LIHO,J)+USOL(LINO,J) + USOL(LINO2,J) + USOL(LINO3,J)
c     3  + 2.*USOL(LI2,J) + USOL(LICL,J) + 2.*USOL(LI2O2,J) 
c     4  + 2.*USOL(LI2O3,J) + 2.*USOL(LI2O4,J)
c      END DO
c      print *,YI(2)
c      print *,USOL(LIHO,1)
c      print *,USOL(LI2,1)
c      print *,USOL(LI2O3,1)
c
      write(90,190)
 190  FORMAT(/1X,'ATMOSPHERIC PARAMETERS')
      write(90,195)
 195  FORMAT(/4X,'Z',9X,'T',9X,'EDD',7X,'DEN',6x,'PRESSURE',5x,'IY')
      write(90,200)(Z(I),T(I),EDD(I),DEN(I),PRESS(I),YI(I),
     2  I=1,NZ,ISKIP)
 200  FORMAT(1X,1P6E10.3)
C
      write(90,230)
 230  FORMAT(/1X,'SULFATE AEROSOL PARAMETERS')
      write(90,235)
 235  FORMAT(/4X,'Z',8X,'AERSOL',5X,'RPAR',6X,'WFALL',5X,'FSULF',4X,
     2  'TAUSED',4X,'TAUEDD',4X,'TAUC',6X,'H2SO4S',4X,'H2SO4',5X,
     3  'CONSO4',4X,'CONVER')
      write(90,240) (Z(I),AERSOL(I,1),RPAR(I,1),
     & WFALL(I,1),FSULF(I),
     2  TAUSED(I,1),TAUEDD(I),TAUC(I,1),H2SO4S(I),USOL(LH2SO4,I),
     3  CONSO4(I),CONVER(I,1),I=1,NZ,ISKIP)
 240  FORMAT(1X,1P12E10.3)
C
C   Calculate total hydrogen mixing ratio and write to a file
      write(86,122)
 122  format(5x,'zkm',6x,'totH2O',4x,'totH',6x,'totH2',4x,'totCH4',
     2  4x,'tothyd','O3')
      DO I=1,NZ
      zkm = Z(I)/1.E5
      totH2O = USOL(LH2O,I)
      totH = USOL(LH,I)*0.5
      totH2 = USOL(LH2,I)
      totCH4 = USOL(LCH4,I)*2.
      tothyd = totH2O + totH + totH2 + totCH4
      if(I.eq.JTROP) tothytrop = tothyd
      if(I.eq.90) tothyhom = tothyd
      write(86,121) zkm,totH2O,totH,totH2,totCH4,tothyd,O3(I)
      END DO
      close(86)  
 121  FORMAT(1x,1p7e10.3)
C
C Calculate hydrogen escape (in units of H2) based on tothyd at the top
C of the model. Do this both approximately and accurately.
C Approximate
      H2escape1 = 2.5e13*tothyhom
C Accurate
      H2escape2 = FUP(LH2O) + 0.5*FUP(LH) + FUP(LH2) + 2.*FUP(LCH4)
C
      write(90,300)
 300  format(/'Hydrogen escape rate in units of H2 molecules')
      write(90,301) H2escape1
 301  format(5x,'Approximate escape rate =',1pe10.3)
      write(90,302) H2escape2
 302  format(5x,'Escape rate calculated from FUP =',1pe10.3)
      write(90,303) tothyhom
 303  format(5x,'Total hydrogen mixing ratio at the homopause = ',
     2  1pe10.3)
      write(90,304) tothytrop
 304  format(5x,'Total hydrogen mixing ratio at the tropopause =',
     2  1pe10.3)

c in may 9 2019, JL add reaction rate table to the code to make life easier
      if (N.EQ.NSTEPS) THEN      
      REWIND 61
      READ(61,2000)CHEM
2000  FORMAT(10X,A8,2X,A8,2X,A8,2X,A8,2X,A8)
      write(15,2001)(J,(CHEM(M,J),M=1,5),J=1,NR)
2001  FORMAT(1X,I3,1H),5X,A8,4H +  ,A8,7H  =    ,A8,4H +  ,A8,4X,A8)
      DO 702 I=1,NSP
         ISP = ISPEC(I)
         WRITE(15,703) ISP,TP(I)
 703     FORMAT(/A8,12X,'PRODUCTION RXS',14X,'INT RX RATE',4X,
     2      'TP = ',1PE9.2)
       DO 704 N=1,NR 
          IF(JCHEM(3,N).EQ.I .OR. JCHEM(4,N).EQ.I .OR. 
     2       JCHEM(5,N).EQ.I)THEN
           IF(RAT(N).NE.0.) WRITE(15,705) N,(CHEM(J,N),J=1,5),RAT(N)
 705       FORMAT(1X,I3,1H),1X,A7,3H + ,A7,3H = ,A7,3H + ,A6,2X,A4,
     2      1PE10.3)
          ENDIF
 704   CONTINUE
C
      WRITE(15,706) ISP,TL(I)
 706     FORMAT(/A8,15X,'LOSS RXS',16X,'INT RX RATE',4X,'TL = ',1PE9.2)
       DO 707 N=1,NR 
          IF(JCHEM(1,N).EQ.I .OR. JCHEM(2,N).EQ.I)THEN
             IF(RAT(N).NE.0.) WRITE(15,705) N,(CHEM(J,N),J=1,5),RAT(N)
          ENDIF
 707   CONTINUE
 702  CONTINUE
C      
      close(61)
      END IF      
      close(15)
      close(90)
      RETURN
      END

